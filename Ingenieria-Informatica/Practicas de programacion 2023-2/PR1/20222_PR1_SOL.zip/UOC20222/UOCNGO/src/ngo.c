#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "project.h"
#include "ngo.h"

// Initialize a NGO
void ngo_init(tNGO *ngo, const char *code, const char *name)
{
	assert(ngo != NULL);
	assert(code != NULL);
	assert(name != NULL);

	// Allocate memory for the code
	ngo->code = (char*) malloc(strlen(code) + 1);
	assert(ngo->code != NULL);
	strcpy(ngo->code, code);

	// Allocate memory for the name
	ngo->name = (char*) malloc(strlen(name) + 1);
	assert(ngo->name != NULL);
	strcpy(ngo->name, name);

	projectList_init(&(ngo->projects));
}

// Release a NGO's data
void ngo_free(tNGO *ngo)
{
	assert(ngo != NULL);

	// Release code memory
	if (ngo->code != NULL)
	{
		free(ngo->code);
		ngo->code = NULL;
	}

	// Release name memory
	if (ngo->name != NULL)
	{
		free(ngo->name);
		ngo->name = NULL;
	}

	// Remove projects
	projectList_free(&(ngo->projects));

}

// Initialize a list of ngos
void ngoList_init(tNGOList *list)
{
	assert(list != NULL);

	list->first = NULL;
	list->count = 0;

}

// Release a list of ngos
void ngoList_free(tNGOList *list)
{
	tNGONode *pNode = NULL;
	tNGONode *pAux = NULL;

	assert(list != NULL);

	pNode = list->first;
	while (pNode != NULL)
	{
		// Store the position of the current node
		pAux = pNode;

		projectList_free(&(pAux->elem.projects));

		// Move to the next node in the list
		pNode = pNode->next;

		// Remove previous node
		ngo_free(&(pAux->elem));
		free(pAux);
	}

	// Initialize to an empty list
	ngoList_init(list);

}

// Insert a new ngo in a list
void ngoList_insert(tNGOList *list, const char *code, const char *name)
{
	tNGONode * pNode;
	tNGONode * pAux;

	assert(list != NULL);
	assert(code != NULL);
	assert(name != NULL);

	if (ngoList_find(list, code) == NULL)
	{
		// Check if insertion point is the first position
		if (list->first == NULL || strcmp(list->first->elem.code, code) > 0)
		{
			// Insert as initial position
			pAux = list->first;
			list->first = (tNGONode*) malloc(sizeof(tNGONode));
			assert(list->first != NULL);
			list->first->next = pAux;
			ngo_init(&(list->first->elem), code, name);
		}
		else
		{
			// Search insertion point
			pAux = list->first;
			pNode = pAux->next;
			while (pNode != NULL && strcmp(pNode->elem.code, code) > 0)
			{
				pAux = pNode;
				pNode = pNode->next;
			}

			pAux->next = (tNGONode*) malloc(sizeof(tNGONode));
			assert(pAux->next != NULL);
			pAux->next->next = pNode;
			ngo_init(&(pAux->next->elem), code, name);
		}

		// Increase the number of elements
		list->count++;
	}
}

// Find a ngo in a list
tNGO* ngoList_find(tNGOList *list, const char *code)
{
	tNGONode * pNode;
	tNGO * pNGO;

	assert(list != NULL);

	// Search center with provided code
	pNode = list->first;
	pNGO = NULL;
	while (pNode != NULL && pNGO == NULL)
	{
		if (strcmp(code, pNode->elem.code) == 0)
		{
			pNGO = &(pNode->elem);
		}

		pNode = pNode->next;
	}

	return pNGO;
}

// Get the number of ngos
int ngoList_len(tNGOList *list)
{
	return list->count;
}

// function to print list of NGO
void ngoList_print(tNGOList *list)
{
	tNGONode * pNode;
	tNGO * pNGO;

	assert(list != NULL);

	pNode = list->first;
	pNGO = NULL;
	while (pNode != NULL && pNGO == NULL)
	{
		printf("ngo %s code %s\n", pNode->elem.name, pNode->elem.code);
		pNode = pNode->next;
	}
}

// Parse input from CSVEntry  
void ngo_parse(tNGO *ngo, tCSVEntry entry)
{
	char *code;
	char *name;
	int indName = 1, indOngCode = 0;

	// Check input data
	assert(ngo != NULL);

	// Check entry fields
	assert(csv_numFields(entry) == 2 || csv_numFields(entry) == 5);

	// Copy NGO code
	code = (char*) malloc((strlen(entry.fields[indOngCode]) + 1) *sizeof(char));
	assert(code != NULL);
	csv_getAsString(entry, indOngCode, code, strlen(entry.fields[indOngCode]) + 1);

	// Copy NGO name
	name = (char*) malloc((strlen(entry.fields[indName]) + 1) *sizeof(char));
	assert(name != NULL);
	csv_getAsString(entry, indName, name, strlen(entry.fields[indName]) + 1);

	// Initialize the NGO with entry data
	ngo_init(ngo, code, name);

	// Remove temporal fields
	free(name);
	free(code);
}