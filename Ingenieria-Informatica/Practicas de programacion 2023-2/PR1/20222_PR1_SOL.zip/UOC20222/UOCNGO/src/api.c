#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "csv.h"
#include "api.h"
#include "error.h"
#include <string.h>
#include "person.h"
#include "ngo.h"
#define FILE_READ_BUFFER_SIZE 2048

// Get the API version information
const char *api_version()
{
	return "UOC PP 20222";
}

// Load data from a CSV file. If reset is true, remove previous data of the App
tError api_loadData(tApiData *data, const char *filename, bool reset)
{
	tError error;
	FILE * fin;
	char buffer[FILE_READ_BUFFER_SIZE];
	tCSVEntry entry;

	// Check input data
	assert(data != NULL);
	assert(filename != NULL);

	// Reset current data    
	if (reset)
	{
		// Remove previous information
		error = api_freeData(data);
		if (error != E_SUCCESS)
		{
			return error;
		}

		// Initialize the data
		error = api_initData(data);
		if (error != E_SUCCESS)
		{
			return error;
		}
	}

	// Open the input file
	fin = fopen(filename, "r");
	if (fin == NULL)
	{
		return E_FILE_NOT_FOUND;
	}

	// Read file line by line
	while (fgets(buffer, FILE_READ_BUFFER_SIZE, fin))
	{
		// Remove new line character     
		buffer[strcspn(buffer, "\n\r")] = '\0';

		csv_initEntry(&entry);
		csv_parseEntry(&entry, buffer, NULL);
		// Add this new entry to the api Data
		error = api_addDataEntry(data, entry);
		if (error != E_SUCCESS)
		{
			return error;
		}

		csv_freeEntry(&entry);
	}

	fclose(fin);

	return E_SUCCESS;
}

// Initialize the data structure of the App
tError api_initData(tApiData *data)
{
	//////////////////////////////////
	// Ex PR1 2b
	/////////////////////////////////
	// Check input data structure
	assert(data != NULL);

	// Initialize data structures
	people_init(&(data->people));
	ngoList_init(&(data->NGOs));
	return E_SUCCESS;

	/////////////////////////////////
	// return E_NOT_IMPLEMENTED;

}

// Add a new person in the data of the App if it doesn't exist
// if the entry is not "PERSON" it will return E_INVALID_ENTRY_TYPE
// if the entry doesn't follow the format "id_number;Name;LastName;email;address;telephone;birthday" it will return E_INVALID_ENTRY_FORMAT
tError api_addPerson(tApiData *data, tCSVEntry entry)
{
	int index;
	tPerson person;
	tPerson * pPerson;

	// Check input data structure
	assert(data != NULL);

	// Check the entry type
	if (strcmp(csv_getType(&entry), "PERSON") != 0)
	{
		return E_INVALID_ENTRY_TYPE;
	}

	// Check the number of fields
	if (csv_numFields(entry) != 7)
	{
		return E_INVALID_ENTRY_FORMAT;
	}

	// Parse the entry
	person_parse(&person, entry);

	// Check if person exists
	index = people_find(data->people, person.document);
	if (index == -1)
	{
		// Add the donor
		people_add(&(data->people), person);
		index = people_find(data->people, person.document);
	}

	assert(index != -1);
	
	person_free(&person);
	return E_SUCCESS;

}

// Increase the budget of an NGO's project in the App data
// If the NGO or the Project doesn't exist, it will create a new one in the App data
// if the entry is not "DONATION" it will return E_INVALID_ENTRY_TYPE
// if the entry doesn't follow the format "ongCode;ongName;ProjectCode;budget" it will return E_INVALID_ENTRY_FORMAT
tError api_addDonation(tApiData *data, tCSVEntry entry)
{
	//////////////////////////////////
	// Ex PR1 2c
	/////////////////////////////////
	tNGO ngo;
	tNGO * pNGO;
	tProject project;
	tProject * pProject;

	// Check input data structure
	assert(data != NULL);

	// Check the entry type
	if (strcmp(csv_getType(&entry), "DONATION") != 0)
	{
		return E_INVALID_ENTRY_TYPE;
	}

	// Check the number of fields
	if (csv_numFields(entry) != 5)
	{
		return E_INVALID_ENTRY_FORMAT;
	}

	// Parse the entry ngo
	ngo_parse(&ngo, entry);

	// Check if ngo exists
	pNGO = ngoList_find(&(data->NGOs), ngo.code);
	if (pNGO == NULL)
	{
		// Add the ngo
		ngoList_insert(&(data->NGOs), ngo.code, ngo.name);
		pNGO = ngoList_find(&(data->NGOs), ngo.code);
	}

	assert(pNGO != NULL);

	// Parse the entry project
	project_parse(&project, entry);

	// Check if project exists
	pProject = projectList_find(&(pNGO->projects), project.code);
	if (pProject == NULL)
	{
		// Add the project
		projectList_insert(&(pNGO->projects), project.code, project.ngoCode, project.budget);
		pProject = projectList_find(&(pNGO->projects), project.code);
	}

	// if the project exists, we increment the budget
	else
	{
		pProject->budget += project.budget;
	}

	assert(pProject != NULL);

	ngo_free(&ngo);
	project_free(&project);

	return E_SUCCESS;

}

// Get the number of people on the App
int api_peopleCount(tApiData data)
{
	//////////////////////////////////
	// Ex 2.d
	/////////////////////////////////
	return people_len(data.people);
}

// Get the number of ngos registered on the App
int api_ngoCount(tApiData data)
{
	//////////////////////////////////
	// Ex 2.d
	/////////////////////////////////
	return ngoList_len(&data.NGOs);
}

// Get the number of projects registered on the App of and NGO
int api_projectCount(tApiData data)
{
	//////////////////////////////////
	// Ex 2.d
	/////////////////////////////////
	int numberProjects = 0;

	tNGONode * pNode;
	tNGO * pNGO;

	pNode = data.NGOs.first;
	pNGO = NULL;
	while (pNode != NULL && pNGO == NULL)
	{
		numberProjects += projectList_len(pNode->elem.projects);
		pNode = pNode->next;
	}

	return numberProjects;

}

// Get the budget registered on the App
float api_ngoProjectBudget(tApiData data, const char *ngoCode, const char *projectCode)
{
	//////////////////////////////////
	// Ex 2.d
	/////////////////////////////////
	float budget = 0.0;
	tNGO * pNGO;
	tProject * pProject;

	assert(ngoCode != NULL);
	assert(projectCode != NULL);

	pNGO = ngoList_find(&(data.NGOs), ngoCode);
	if (pNGO != NULL)
	{
		pProject = projectList_find(&(pNGO->projects), projectCode);
		if (pProject != NULL)
		{
			budget = pProject->budget;
		}
	}

	return budget;

}

// Free all used memory in the App
tError api_freeData(tApiData *data)
{
	//////////////////////////////////
	// Ex PR1 2e
	/////////////////////////////////
	people_free(&(data->people));
	ngoList_free(&(data->NGOs));

	return E_SUCCESS;
	/////////////////////////////////
	//return E_NOT_IMPLEMENTED;

}

// Add a new entry to the CSV
tError api_addDataEntry(tApiData *data, tCSVEntry entry)
{
	//////////////////////////////////
	// Ex PR1 2f
	/////////////////////////////////
	int personIdx;
	tPerson person;

	assert(data != NULL);

	// Initialize the person object
	person_init(&person);

	if (strcmp(csv_getType(&entry), "PERSON") == 0)
	{
		// Check the number of fields
		if (csv_numFields(entry) != 7)
		{
			return E_INVALID_ENTRY_FORMAT;
		}

		// Parse the data
		person_parse(&person, entry);

		// Check if person exists
		personIdx = people_find(data->people, person.document);
		if (personIdx == -1)
		{
			// Add the donor
			people_add(&(data->people), person);
			personIdx = people_find(data->people, person.document);
		}

		assert(personIdx != -1);

		// Release person object
		person_free(&person);
	}
	else if (strcmp(csv_getType(&entry), "DONATION") == 0)
	{
		return api_addDonation(data, entry);

	}
	else
	{
		return E_INVALID_ENTRY_TYPE;
	}

	return E_SUCCESS;
	/////////////////////////////////
	//return E_NOT_IMPLEMENTED;

}

// Get NGO data from the App
tError api_getNGO(tApiData data, const char *ngoCode, tCSVEntry *entry)
{
	//////////////////////////////////
	// Ex PR1 3a
	/////////////////////////////////
	char buffer[2048];
	tNGO *pNGO = NULL;

	assert(ngoCode != NULL);
	assert(entry != NULL);

	// Search the ngo
	pNGO = ngoList_find(&(data.NGOs), ngoCode);

	if (pNGO == NULL)
	{
		return E_NOT_FOUND;
	}

	// Print data in the buffer
	sprintf(buffer, "%s;%s", pNGO->code, pNGO->name);

	// Initialize the output structure
	csv_initEntry(entry);
	csv_parseEntry(entry, buffer, "NGO");

	return E_SUCCESS;

}


// Get Project data
tError api_getProject(tApiData data, const char *ngoCode, const char *projectCode, tCSVEntry *entry)
{
	//////////////////////////////////
	// Ex PR1 3b
	/////////////////////////////////
	char buffer[2048];
	tProject *pProject = NULL;
	tNGO *pNGO = NULL;

	assert(ngoCode != NULL);
	assert(projectCode != NULL);
	assert(entry != NULL);

	// find the NGO
	pNGO = ngoList_find(&(data.NGOs), ngoCode);
	if (pNGO == NULL)
	{
		return E_NOT_FOUND;
	}

	assert(pNGO != NULL);

	// find the project
	pProject = projectList_find(&(pNGO->projects), projectCode);
	if (pProject == NULL)
	{
		return E_NOT_FOUND;
	}

	// Print data in the buffer
	sprintf(buffer, "%s;%s;%.2f", pProject->code, pProject->ngoCode, pProject->budget);

	// Initialize the output structure
	csv_initEntry(entry);
	csv_parseEntry(entry, buffer, "PROJECT");
	return E_SUCCESS;

}

// Get vaccine data from the App
tError api_getNGOs(tApiData data, tCSVData *ngos)
{
	//////////////////////////////////
	// Ex PR1 3c
	/////////////////////////////////
	char buffer[2048];
	tNGONode * pNode;
	tNGO * pNGO;

	csv_init(ngos);
	pNode = data.NGOs.first;
	pNGO = NULL;
	while (pNode != NULL && pNGO == NULL)
	{
		sprintf(buffer, "%s;%s", pNode->elem.code, pNode->elem.name);
		csv_addStrEntry(ngos, buffer, "NGO");
		pNode = pNode->next;
	}

	return E_SUCCESS;

}

// Get registered projects from the app
tError api_getProjects(tApiData data, tCSVData *projects){
	//////////////////////////////////
	// Ex PR1 3d
	/////////////////////////////////
	char buffer[2048];
	tNGONode * pNGONode;
	tNGO * pNGO;
	tProjectNode * pProjectNode;
	tProject * pProject;

	csv_init(projects);
	pNGONode = data.NGOs.first;
	pNGO = NULL;
	while (pNGONode != NULL && pNGO == NULL)
	{
		pProjectNode = pNGONode->elem.projects.first;
		pProject = NULL;
		while (pProjectNode != NULL && pProject == NULL)
		{
			sprintf(buffer, "%s;%s;%.2f", pProjectNode->elem.code, pProjectNode->elem.ngoCode, pProjectNode->elem.budget);
			csv_addStrEntry(projects, buffer, "PROJECT");
			pProjectNode = pProjectNode->next;

		}
		pNGONode = pNGONode->next;
		
	}

	return E_SUCCESS;

}