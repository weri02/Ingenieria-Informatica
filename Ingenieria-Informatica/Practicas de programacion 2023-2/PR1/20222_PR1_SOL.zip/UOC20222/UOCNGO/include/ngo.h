#ifndef __NGO__H
#define __NGO__H
#include "project.h"
#include "csv.h"

// NGO 
typedef struct _tNGO
{
	char *code;
	char *name;
	tProjectList projects;
}

tNGO;

// NGO list node
typedef struct _tNGONode
{
	tNGO elem;
	struct _tNGONode * next;
}

tNGONode;

// NGO list node
typedef struct _tNGOList
{
	tNGONode * first;
	int count;

}

tNGOList;

// Initialize a NGO
void ngo_init(tNGO *ngo, const char *code, const char *name);

// Release a NGO's data
void ngo_free(tNGO *ngo);

// Initialize a list of ngos
void ngoList_init(tNGOList *list);

// Get the number of ngos
int ngoList_len(tNGOList *list);

// Release a list of ngos
void ngoList_free(tNGOList *list);

// Insert a new ngo
void ngoList_insert(tNGOList *list, const char *code, const char *name);

// Find a ngo
tNGO* ngoList_find(tNGOList *list, const char *code);

//function to print list of NGO
void ngoList_print(tNGOList *list);

// Parse input from CSVEntry
void ngo_parse(tNGO *ngo, tCSVEntry entry);


#endif	// __NGO_H__