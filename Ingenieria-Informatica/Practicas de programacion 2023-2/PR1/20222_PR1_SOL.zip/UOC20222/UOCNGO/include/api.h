#ifndef __UOCNGO_API__H
#define __UOCNGO_API__H
#include <stdbool.h>
#include "error.h"
#include "csv.h"
#include "project.h"
#include "person.h"
#include "ngo.h"

// Define an error type
typedef enum _tError tError;

// Type that stores all the application data
typedef struct _ApiData
{
	////////////////////////////////
	// PR1 EX2a
	////////////////////////////////  
	tPeople people;
	// NGOs
	tNGOList NGOs;
	////////////////////////////////

}

tApiData;

// Get the API version information
const char *api_version();

// Load data from a CSV file. If reset is true, remove previous data
tError api_loadData(tApiData *data, const char *filename, bool reset);

// Add a new entry
tError api_addDataEntry(tApiData *data, tCSVEntry entry);

// Free all used memory
tError api_freeData(tApiData *data);

// Initialize the data structure
tError api_initData(tApiData *data);

// Add a new Donor
tError api_addPerson(tApiData *data, tCSVEntry entry);

// Add a new donation to the App
tError api_addDonation(tApiData *data, tCSVEntry entry);

// Get NGO data from CSV entry
tError api_getNGO(tApiData data, const char *ngoCode, tCSVEntry *entry);

// Get project data from CSV entry
tError api_getProject(tApiData data, const char *ngoCode, const char *projectCode, tCSVEntry *entry);

// Get registered NGOs from the app
tError api_getNGOs(tApiData data, tCSVData *ngos);

// Get registered projects from the app
tError api_getProjects(tApiData data, tCSVData *projects);

// Get the number of people registered on the app
int api_peopleCount(tApiData data);

// Get the number of NGOs registered on the app
int api_ngoCount(tApiData data);

// Get the number of projects registered on the app
int api_projectCount(tApiData data);

// Get the budget registered on a the app
float api_ngoProjectBudget(tApiData data, const char *ngoCode, const char *projectCode);


#endif	// __UOCNGO_API__H