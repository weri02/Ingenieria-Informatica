#ifndef __PROJECT__H
#define __PROJECT__H

#include "csv.h"

typedef struct _tProject {    
    char* code;
	char* ngoCode ;
	float budget;
} tProject;

// Project list node
typedef struct _tProjectNode {   
    tProject elem;
    struct _tProjectNode *next;
} tProjectNode;


// Project list node
typedef struct _tProjectList {    
    tProjectNode* first;
    int count;
} tProjectList;


// Initialize project data
void project_init(tProject* project, const char* code, const char* ngo, float budget);

// Release project data
void project_free(tProject* project);

// Copy the data of a project from the source to destination
void project_cpy(tProject* destination, tProject source);

// Parse input from CSVEntry  
void project_parse(tProject* project, tCSVEntry entry);

// Initialize the project List
void projectList_init(tProjectList* list);

// Remove all elements
void projectList_free(tProjectList* list);

// Get the number of projects
int projectList_len(tProjectList list);

// Add a new project
void projectList_insert(tProjectList* list, const char* projectCode, const char* ngoCode, float budget);

// Remove project
void projectList_del(tProjectList* list, const char* code);

// Find a project
tProject* projectList_find(tProjectList* list, const char* code);



#endif // __PROJECT__H