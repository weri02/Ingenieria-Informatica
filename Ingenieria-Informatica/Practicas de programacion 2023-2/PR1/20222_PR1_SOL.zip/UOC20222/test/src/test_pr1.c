#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr1.h"
#include "api.h"

// Run all tests for PR1
bool run_pr1(tTestSuite* test_suite, const char* input) {
    bool ok = true;
    tTestSection* section = NULL;

    assert(test_suite != NULL);

    testSuite_addSection(test_suite, "PR1", "Tests for PR1 exercises");

    section = testSuite_getSection(test_suite, "PR1");
    assert(section != NULL);

    ok = run_pr1_ex1(section, input);
    ok = run_pr1_ex2(section, input) && ok;
    ok = run_pr1_ex3(section, input) && ok;

    return ok;
}

// Run all tests for Exercice 1 of PR1
bool run_pr1_ex1(tTestSection* test_section, const char* input) {
    bool passed = true, failed = false;
    const char* version;
    
    /////////////////////////////
    /////  PR1 EX1 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX1_1", "Read version information.");
    // Get the version
    version = api_version();
    if (strcmp(version, "UOC PP 20222") != 0) {
        failed = true;
        passed = false;
    }
    end_test(test_section, "PR1_EX1_1", !failed);
    
    return passed;
}

// Run all tests for Exercice 2 of PR1
bool run_pr1_ex2(tTestSection* test_section, const char* input) {
    tApiData data;
    tError error;
    tCSVEntry donation, entry;    
	float budget;
    int numberNGOs, numberProjects, numberPeople;   
	tState state;

    /////////////////////////////
    /////  PR1 EX2 TEST 1  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_1", "Initialize the API data structure");
    // Initialize the data  
    test_state_init(&state);  
    error = api_initData(&data);
	assertIntEquals(test_section, "PR1_EX2_1", "error", E_SUCCESS, error, &state);

    end_test(test_section, "PR1_EX2_1", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 2  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_2", "Add a valid donation");
	if (state.fail_all) {
		state.failed = true;		
	}else {
		csv_initEntry(&donation);
		csv_parseEntry(&donation, "FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;2500.00;X6408356G", "DONATION");
        error = api_addDonation(&data, donation);
		assertIntEquals(test_section, "PR1_EX2_2", "error", E_SUCCESS, error, &state);

       
		csv_freeEntry(&donation);
    }
    end_test(test_section, "PR1_EX2_2", !state.failed);
           
    /////////////////////////////
    /////  PR1 EX2 TEST 3  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_3", "Check the number of NGOs and projects");
	if (state.fail_all) {
		state.failed = true;
    } else {
        numberNGOs = api_ngoCount(data);    		
		numberProjects =  api_projectCount(data); 
		assertIntEquals(test_section, "PR1_EX2_3", "numberNGOs!=1", 1, numberNGOs, &state);
 		assertIntEquals(test_section, "PR1_EX2_3", "numberProjects!=1", 1, numberProjects, &state);

    }
    end_test(test_section, "PR1_EX2_3", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 4  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_4", "Check the if the budget has been updated");
	if (state.fail_all) {
		state.failed = true;
    } else {        
        budget = api_ngoProjectBudget(data,"FOOD_BANK_BCN","BARCELONA");
		assertFloatEquals(test_section, "PR1_EX2_4", "api_ngoProjectBudget budget!=2500.0", 2500.000000, budget, &state);

		csv_initEntry(&donation);
		csv_parseEntry(&donation, "FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;1500.50;X6408356G", "DONATION");
        error = api_addDonation(&data, donation);
		assertIntEquals(test_section, "PR1_EX2_4", "error", E_SUCCESS, error, &state);

		csv_freeEntry(&donation);
		budget = api_ngoProjectBudget(data,"FOOD_BANK_BCN","BARCELONA");
		assertFloatEquals(test_section, "PR1_EX2_4", "api_ngoProjectBudget budget!=4000.50", 4000.50f, budget, &state);

    }
	
	
    end_test(test_section, "PR1_EX2_4", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 5  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_5", "Add a donation with invalid type");    
	if (state.fail_all) {
		state.failed = true;
    } else {
		csv_freeEntry(&donation);
        csv_parseEntry(&donation, "FESBAL;Spanish Federation of Food Banks;MADRID;2500.00;X6408356G", "DONATION_NGO");
        error = api_addDonation(&data, donation);
		assertIntEquals(test_section, "PR1_EX2_5", "error api_addDonation != E_INVALID_ENTRY_TYPE", E_INVALID_ENTRY_TYPE, error, &state);

        csv_freeEntry(&donation);
    }
    end_test(test_section, "PR1_EX2_5", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 6  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_6", "Add a donation with invalid fields");    
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_initEntry(&donation);
        csv_parseEntry(&donation, "YMCA;Young Mens Christian Association;NEW_YORK;5000.00;X6408356G;extra field", "DONATION");
        error = api_addDonation(&data, donation);
		assertIntEquals(test_section, "PR1_EX2_6", "api_addDonation != E_INVALID_ENTRY_FORMAT", E_INVALID_ENTRY_FORMAT, error, &state);

        csv_freeEntry(&donation);
    }
    end_test(test_section, "PR1_EX2_6", !state.failed);
	
	 /////////////////////////////
    /////  PR1 EX2 TEST 7  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_7", "Add people as donors and check format");    
	if (state.fail_all) {
		state.failed = true;
    } else {
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "87654321K;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980", "PERSON");
        error = api_addPerson(&data, entry);
		assertIntEquals(test_section, "PR1_EX2_7", "api_addDonation != E_SUCCESS", E_SUCCESS, error, &state);

		csv_freeEntry(&entry);
		
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985", "PEOPLE");
        error = api_addPerson(&data, entry);
		assertIntEquals(test_section, "PR1_EX2_7", "api_addPerson != E_INVALID_ENTRY_TYPE", E_INVALID_ENTRY_TYPE, error, &state);

		csv_freeEntry(&entry);
		
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985;extra field", "PERSON");
        error = api_addPerson(&data, entry);
		assertIntEquals(test_section, "PR1_EX2_7", "api_addPerson != E_INVALID_ENTRY_FORMAT", E_INVALID_ENTRY_FORMAT, error, &state);

		csv_freeEntry(&entry);
		
        csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985","PERSON");  
        error = api_addPerson(&data, entry);   
		assertIntEquals(test_section, "PR1_EX2_7", "error", E_SUCCESS, error, &state);

		csv_freeEntry(&entry);

		numberPeople = api_peopleCount(data); 

		assertIntEquals(test_section, "PR1_EX2_7", "api_peopleCount != 2", 2, numberPeople, &state);
   	
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Y3168793M;Alice;Jones;alice.jones@example.com;Other street, 11;+2-100-444-1234;28/02/1992", "PERSON");
        error = api_addPerson(&data, entry);   
		assertIntEquals(test_section, "PR1_EX2_7", "error", E_SUCCESS, error, &state);

		csv_freeEntry(&entry);
		
		numberPeople = api_peopleCount(data);    
		assertIntEquals(test_section, "PR1_EX2_7", "api_peopleCount != 3", 3, numberPeople, &state);
	
    }
    end_test(test_section, "PR1_EX2_7", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 8  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_8", "Free API data");    
	if (state.fail_all) {
		state.failed = true;
    } else {        
        error = api_freeData(&data);
        numberNGOs = api_ngoCount(data);
        numberPeople = api_peopleCount(data);
		assertIntEquals(test_section, "PR1_EX2_8", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX2_8", "numberNGOs != 0", 0, numberNGOs, &state);
		assertIntEquals(test_section, "PR1_EX2_8", "numberPeople != 0", 0, numberPeople, &state);
		//assertIsNULL(test_section, "PR1_EX2_8", "data.people.elems  != NULL", &data.people.elems, &state);
		//assertIsNULL(test_section, "PR1_EX2_8", "data.NGOs.first != NULL", &data.NGOs.first , &state);

    }
    end_test(test_section, "PR1_EX2_8", !state.failed);
    
    
    /////////////////////////////
    /////  PR1 EX2 TEST 9  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX2_9", "Load data from file");
    // Load basic data to the API
	if (state.fail_all) {
		state.failed = true;
    } else {
        error = api_loadData(&data, input, true);
        numberNGOs = api_ngoCount(data);
		numberPeople = api_peopleCount(data);
		numberProjects =  api_projectCount(data); 
		assertIntEquals(test_section, "PR1_EX2_9", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX2_9", "numberNGOs != 3", 3, numberNGOs, &state);
		assertIntEquals(test_section, "PR1_EX2_9", "numberPeople != 3", 3, numberPeople, &state);
		assertIntEquals(test_section, "PR1_EX2_9", "numberProjects != 3", 3, numberProjects, &state);

    }
    end_test(test_section, "PR1_EX2_9", !state.failed);
    
    // Release all data
    api_freeData(&data);
    
    return state.passed;
}


// Run all tests for Exercice 3 of PR1
bool run_pr1_ex3(tTestSection* test_section, const char* input) {
    tApiData data;
    tError error;
    tCSVEntry entry;
    tCSVEntry refEntry;
    tCSVData report;
    tCSVData refReport;
	bool equalsEntry;
	tState state;
    int numberNGOs, numberPeople, numberProjects;
    

    
    
    /////////////////////////////
    /////  PR1 EX3 TEST 1  //////
    /////////////////////////////
	
    start_test(test_section, "PR1_EX3_1", "Request a valid NGO");
	
	 // Initialize the data    
	test_state_init(&state);  
    error = api_initData(&data);
	assertIntEquals(test_section, "PR1_EX3_1", "error", E_SUCCESS, error, &state);
   
    
    if (!state.fail_all) {
        error = api_loadData(&data, input, true);
		numberNGOs = api_ngoCount(data);
		numberPeople = api_peopleCount(data);
		numberProjects =  api_projectCount(data); 
		assertIntEquals(test_section, "PR1_EX3_1", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX3_1", "numberNGOs != 3", 3, numberNGOs, &state);
		assertIntEquals(test_section, "PR1_EX3_1", "numberPeople != 3", 3, numberPeople, &state);
		assertIntEquals(test_section, "PR1_EX3_1", "numberProjects != 3", 3, numberProjects, &state);        
    }
	
	if (state.fail_all) {
		state.failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
        csv_parseEntry(&refEntry, "WCK;World Central Kitchen", "NGO");
        error = api_getNGO(data, "WCK", &entry);
		equalsEntry  = csv_equalsEntry(entry, refEntry);
		
		assertIntEquals(test_section, "PR1_EX3_1", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX3_1", "error", true, equalsEntry, &state);

        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_1", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 2  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX3_2", "Request a missing NGO");
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_initEntry(&entry);
        error = api_getNGO(data, "YMCA", &entry);
		assertIntEquals(test_section, "PR1_EX3_2", "api_getNGO!= E_NOT_FOUND", E_NOT_FOUND, error, &state);

        csv_freeEntry(&entry);        
    }
    end_test(test_section, "PR1_EX3_2", !state.failed);
           
    /////////////////////////////
    /////  PR1 EX3 TEST 3  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX3_3", "Request a valid project");
	if (state.fail_all) {
		state.failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
        csv_parseEntry(&refEntry, "UKRANIE;WCK;1000000.00", "PROJECT");
        error = api_getProject(data, "WCK", "UKRANIE", &entry);
		equalsEntry  = csv_equalsEntry(entry, refEntry);
		
		assertIntEquals(test_section, "PR1_EX3_3", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX3_3", "csv_equalsEntry error", true, equalsEntry, &state);
		
        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_3", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 4  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX3_4", "Request a missing Project");
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&refEntry, "SWITZERLAND;WCK;10000.00", "PROJECT");
        error = api_getProject(data, "WCK", "SWITZERLAND", &entry);
		assertIntEquals(test_section, "PR1_EX3_4", "api_getProject != E_NOT_FOUND", E_NOT_FOUND, error, &state);

        csv_freeEntry(&entry);
		csv_freeEntry(&refEntry);
		
    }
    end_test(test_section, "PR1_EX3_4", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 5  //////
    /////////////////////////////
    start_test(test_section, "PR1_EX3_5", "Request a project from a missing NGO");
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_initEntry(&entry);
		csv_parseEntry(&refEntry, "UKRANIE;YMCA;1000000.00", "PROJECT");
        error = api_getProject(data, "YMCA", "UKRANIE", &entry);
		assertIntEquals(test_section, "PR1_EX3_5", "api_getProject != E_NOT_FOUND", E_NOT_FOUND, error, &state);
      
        csv_freeEntry(&entry);
		csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_5", !state.failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 6  //////
    /////////////////////////////
	start_test(test_section, "PR1_EX3_6", "Get registered NGOs");
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);	
		csv_addStrEntry(&refReport, "FESBAL;Spanish Federation of Food Banks", "NGO");
		csv_addStrEntry(&refReport, "WCK;World Central Kitchen", "NGO");
        csv_addStrEntry(&refReport, "FOOD_BANK_BCN;Food Bank from Barcelona", "NGO");
        error = api_getNGOs(data, &report);
		equalsEntry  = csv_equals(report, refReport);

		assertIntEquals(test_section, "PR1_EX3_6", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX3_6", "csv_equals error", true, equalsEntry, &state);
		
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_6", !state.failed);
	
	 /////////////////////////////
    /////  PR1 EX3 TEST 7  //////
    /////////////////////////////	
    start_test(test_section, "PR1_EX3_7", "Get registered Projects");
	if (state.fail_all) {
		state.failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);	
		csv_addStrEntry(&refReport, "MADRID;FESBAL;502500.50", "PROJECT");
		csv_addStrEntry(&refReport, "UKRANIE;WCK;1000000.00", "PROJECT");
		csv_addStrEntry(&refReport, "BARCELONA;FOOD_BANK_BCN;5000.00", "PROJECT");		
        error = api_getProjects(data, &report);
		equalsEntry  = csv_equals(report, refReport);
		
		assertIntEquals(test_section, "PR1_EX3_7", "error", E_SUCCESS, error, &state);
		assertIntEquals(test_section, "PR1_EX3_7", "csv_equals error", true, equalsEntry, &state);
		
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_7", !state.failed);
    
    // Release all data
    api_freeData(&data);
    
    return state.passed;
}
