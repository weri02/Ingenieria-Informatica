#ifndef __TEST_DATA__H
#define __TEST_DATA__H

// Define test data for PR1
// Define test data for PR1
const char* test_data_pr1_str = "PERSON;X6408356G;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980\n" \
								"PERSON;Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985\n" \
								"PERSON;Y3168793M;Alice;Jones;alice.jones@example.com;Other street, 11;+2-100-444-1234;28/02/1992\n" \
								"DONATION;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;5000.00;X6408356G\n" \
								"DONATION;FESBAL;Spanish Federation of Food Banks;MADRID;2500.50;X6408356G\n" \
								"DONATION;FESBAL;Spanish Federation of Food Banks;MADRID;500000.00;Z5446375A\n" \
								"DONATION;WCK;World Central Kitchen;UKRANIE;1000000.00;Y3168793M\n";                           
                      
#endif // TEST_DATA__H