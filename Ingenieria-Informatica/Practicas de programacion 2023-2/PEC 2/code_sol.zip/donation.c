#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "donation.h"

// Parse a tDate from string information
void date_parse(tDate* date, const char* text)
{
    // Check output data
    assert(date != NULL);
    
    // Check input date
    assert(text != NULL);
    assert(strlen(text) == 10);
    
    // Parse the input date
    sscanf(text, "%d/%d/%d", &(date->day), &(date->month), &(date->year));
}

// Compare two tDate structures and return true if they contain the same value or false otherwise.
bool date_equals(tDate date1, tDate date2)
{
    return (date1.day == date2.day && date1.month == date2.month && date1.year == date2.year); 
}

// Initialize the donations data 
void donationData_init (tDonationData* data)
{
    // Check input data (Pre-conditions)
    assert(data != NULL);    
    
    // Set the initial number of elements to zero.
    data->count = 0;
    ///////////////////////
    data->elems = NULL;
    ///////////////////////
}

// Get the number of donations
int donationData_len (tDonationData data)
{
    // Return the number of elements
    return data.count;
}

// Parse input from CSVEntry
void donation_parse (tDonation* donation, tCSVEntry entry)
{
    char date[11];
    
    // Check input data (Pre-conditions)
    assert(donation != NULL);    
    assert(csv_numFields(entry) == 5);
    
    // Get the date 
    csv_getAsString(entry, 0, date, 11);    
    date_parse(&(donation->date), date);
    
    // Assign the person document
    csv_getAsString(entry, 1, donation->personDocument, MAX_DOC_ID + 1);

    // Assign the ngo code
    csv_getAsString(entry, 2, donation->ngo, MAX_NGO_CODE + 1);
        
    // Assign the project code
    csv_getAsString(entry, 3, donation->projectCode, MAX_PROJECT_CODE + 1);

    // Assign the amount
    donation->amount = csv_getAsReal(entry, 4);
}


// Add a new donation
void donationData_add (tDonationData* data, tDonation donation)
{
    int idx, i;
   
    // Check if an entry with this data already exists
    if (!donationData_find(*data, donation.date, donation.personDocument, donation.projectCode, &idx)) 
    {
        // If it does not exist, create a new entry
        /////////////////////////////////
        if (data->elems == NULL) {
            data->elems = (tDonation*) malloc(sizeof(tDonation));
        } else {
            data->elems = (tDonation*) realloc(data->elems, (data->count + 1) * sizeof(tDonation));
        }
        assert(data->elems != NULL);
        //////////////
        //assert(data->count < MAX_DONATIONS);
        //////////////
        for (i=data->count; i>idx; i--)
            donation_copy(&(data->elems[i]), data->elems[i-1]);
        donation_copy(&(data->elems[idx]), donation);
        data->count++;        
    }
}

// Get a donation
void donationData_get (tDonationData data, int index, char* buffer)
{
    tDonation *elem;

    assert(index < data.count);
    elem = &(data.elems[index]);
    sprintf(buffer, "%02d/%02d/%04d;%s;%s;%s;%.2f", elem->date.day, elem->date.month, 
            elem->date.year, elem->personDocument, elem->ngo, elem->projectCode, elem->amount);
}


// Remove a donation
void donationData_del (tDonationData* data, tDate date, const char* personDoc, const char* projectCode)
{
    int idx;
    int i;
    
    // Check input data (Pre-conditions)
    assert(data != NULL);    
    
    // Check if an entry with this data already exists
    if (donationData_find(*data, date, personDoc, projectCode, &idx))
    {
        // Shift elements to remove selected
        for(i = idx; i < data->count-1; i++) {
            // Copy element on position i+1 to position i
            donation_copy(&(data->elems[i]), data->elems[i+1]);
        }
        // Update the number of elements
        data->count--;
        //////////////
        if (data->count > 0) {
            data->elems = (tDonation*) realloc(data->elems, data->count * sizeof(tDonation));
            assert(data->elems != NULL);
        } else {
            free(data->elems);
        }
        //////////////
    }
}

// [AUX METHOD] Return if exists a donation entry with the provided information. If exists, idx contains the position of that entry
bool donationData_find (tDonationData data, tDate date, const char* personDoc, const char* projectCode, int *idx)
{
    int i;
    bool found, end;

    i = 0;
    end = false;
    found = false;
    while ((i < data.count) && !end) 
    {
        if (strcmp(data.elems[i].projectCode, projectCode) > 0) {
           end = true;
        }
        else if ((strcmp(data.elems[i].projectCode, projectCode) == 0) && 
                 (strcmp(data.elems[i].personDocument, personDoc) == 0) && date_equals(data.elems[i].date, date)) { 
           found = true;
           end = true;
        }
        else 
            i++;
    }
   
    *idx = i; 
    return found;
}

// [AUX METHOD] Copy the data from the source to destination
void donation_copy (tDonation* destination, tDonation source)
{
    destination->date = source.date;
    strcpy(destination->personDocument, source.personDocument);
    strcpy(destination->ngo, source.ngo);
    strcpy(destination->projectCode, source.projectCode);
    destination->amount = source.amount;
}

// Remove all elements
void donationData_free(tDonationData* data) 
{
    /////////////////////////////////
    if (data->elems != NULL) {
        free(data->elems);
    }
    donationData_init(data);
    /////////////////////////////////
}
