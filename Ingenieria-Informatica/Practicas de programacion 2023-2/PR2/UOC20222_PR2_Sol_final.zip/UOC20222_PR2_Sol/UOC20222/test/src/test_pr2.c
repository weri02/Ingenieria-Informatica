#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr2.h"
#include "benefactor.h"
#include "ngo.h"
#include "callQueue.h"
#include "api.h"
#include "csv.h"
#include "error.h"

tPerson ben_person1;
tPerson ben_person2;
tPerson ben_person3;

void init_test_people() {
    tCSVEntry entry;
    
	csv_initEntry(&entry);
	csv_parseEntry(&entry, "87654321K;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980", "PERSON");
	person_parse(&ben_person1, entry);
    csv_freeEntry(&entry);
		
	csv_initEntry(&entry);
	csv_parseEntry(&entry, "56754321K;Samantha;Carter;samantha.carter@example.com;Upstreet, 25;+1-302-595-0165;30/12/1986", "PERSON");
	person_parse(&ben_person2, entry);
    csv_freeEntry(&entry);
	
	csv_initEntry(&entry);
	csv_parseEntry(&entry, "57489321B;Daniel;Jackson;daniel.jackson@example.com;Downstreet, 45;+1-302-455-0335;25/01/1977", "PERSON");
	person_parse(&ben_person3, entry);
    csv_freeEntry(&entry);
}

void free_test_people() {
    person_free(&ben_person1);    
    person_free(&ben_person2);    
    person_free(&ben_person3);    
}

void aux_pr2_ex1_initialize_benefactors(tBenefactor* benefactor1, tBenefactor* benefactor2, tBenefactor* benefactor3)
{
    
    init_test_people();
    
	benefactor_init(&ben_person1,benefactor1); 
    benefactor_init(&ben_person2,benefactor2); 
    benefactor_init(&ben_person3,benefactor3); 
	
}


// Run all tests for PR2
bool run_pr2(tTestSuite* test_suite, const char* input)
{
	bool ok = true;
	tTestSection* section = NULL;

	assert(test_suite != NULL);

	testSuite_addSection(test_suite, "PR2", "Tests for PR2 exercises");

	section = testSuite_getSection(test_suite, "PR2");
	assert(section != NULL);

	ok = run_pr2_ex1(section, input);
	ok = run_pr2_ex2(section, input) && ok;
	ok = run_pr2_ex3(section, input) && ok;

	return ok;
}

// Run all tests for Exercice 1 of PR2
bool run_pr2_ex1(tTestSection* test_section, const char* input)
{

	tBenefactorData benefactorData;
	tBenefactor benefactor1; // test data
	tBenefactor benefactor2; // test data
	tBenefactor benefactor3; // test data
	tBenefactor *test1, *test2, *test3; // helpers for comparisons
	tError error;
	bool exercisePassed = true;
	bool testPassed = true; // determines if test is passed or not
	bool t1=false, t2=false, t3=false; // helpers for comparison
	bool fail_all = false;
    int result;
    float am1=276.40, am2=245.40, am3=45.40, total=0.0;

	//creates test data
	aux_pr2_ex1_initialize_benefactors(&benefactor1, &benefactor2, &benefactor3);

	/////////////////////////////
	/////  PR2 EX1 TEST A  //////
	/////////////////////////////    
	start_test(test_section, "PR2_EX1_A", "Initialize Benefactors Data list");

	//Insert an incorrect value
	benefactorData.count=-34;

	// Initialize the data    
	error = benefactorData_init(&benefactorData);

	if (benefactorData.count != 0 || benefactorData.elems != NULL) {
		testPassed= false;
		exercisePassed = false;
		fail_all = true;
        // Perform minimum initialization to avoid memory release errors
        benefactorData.count = 0;
        benefactorData.elems = NULL;
	}
	end_test(test_section, "PR2_EX1_A", testPassed);

	/////////////////////////////
	/////  PR2 EX1 TEST B //////
	/////////////////////////////
	testPassed=false;
	start_test(test_section, "PR2_EX1_B", "Check BenefactorData length");
    if (!fail_all) {
        benefactorData_init(&benefactorData);
        benefactorData_add(&benefactor1, &benefactorData);
        benefactorData_add(&benefactor2, &benefactorData);
        benefactorData_add(&benefactor3, &benefactorData);
        if (benefactorData_len(benefactorData)==3) {
            testPassed=true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    } 
	end_test(test_section, "PR2_EX1_B", testPassed);


	/////////////////////////////
	/////  PR2 EX1 TEST  C  //////
	/////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_C", "Add Benefactor to BenefactorData");
	//No need to check again addition, as they were tested in the previous step for length
	//We check if the addition has been made alphabetically and that duplicates are avoided	
    
    if (!fail_all) {
        //alphabetical order

        result = strcmp(benefactor2.person->document, benefactorData.elems[0].person->document);
        result = result + strcmp(benefactor3.person->document, benefactorData.elems[1].person->document);
        result = result + strcmp(benefactor1.person->document, benefactorData.elems[2].person->document);
        if(result == 0) {
            //check for duplications
            if(benefactorData_add(&benefactor2, &benefactorData) == E_DUPLICATED_PERSON) {
                testPassed=true;
            }
        }
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }     
	end_test(test_section, "PR2_EX1_C", testPassed);

	/////////////////////////////
	/////  PR2 EX1 TEST D  //////
	/////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_D", "Get Benefactor");

    if (!fail_all) {
        test1 = benefactorData_get(-23, benefactorData);
        test2 = benefactorData_get(23, benefactorData);
        test3 = benefactorData_get(2, benefactorData);

        if(test1 == NULL && test2 == NULL && test3 !=NULL) {
            if(strcmp(test3->person->document, benefactor1.person->document) ==0) {
                testPassed = true;
            }
        }
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX1_D", testPassed);

	/////////////////////////////
	/////  PR2 EX1 TEST E  //////
	/////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_E", "Delete Benefactor");
    if (!fail_all) {
        error=benefactorData_del("45330771B", &benefactorData);
        if(error == E_NOT_FOUND) {
            error=benefactorData_del(benefactor2.person->document, &benefactorData);
            t1 = strcmp(benefactor3.person->document, benefactorData.elems[0].person->document);
            t2 = strcmp(benefactor1.person->document, benefactorData.elems[1].person->document);
            t3= benefactorData.count == 2;
            if (!t1 && !t2 && t3 && error == E_SUCCESS) {
                error=benefactorData_del(benefactor1.person->document, &benefactorData);
                error=benefactorData_del(benefactor3.person->document, &benefactorData);
                if(benefactorData.count == 0 && benefactorData.elems == NULL) {
                    testPassed=true;
                }
            }
        }
        test1=NULL;
        test2=NULL;
        test3=NULL;
        benefactorData_add(&benefactor1, &benefactorData);
        benefactorData_add(&benefactor2, &benefactorData);
        benefactorData_add(&benefactor3, &benefactorData);
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX1_E", testPassed);


	/////////////////////////////
	/////  PR2 EX1 TEST F  //////
	/////////////////////////////
	testPassed = false;

	start_test(test_section, "PR2_EX1_F", "Find Benefactor by ID");
    if (!fail_all) {
        test1= benefactorData_find("45330771B", benefactorData); //Not existing in the list
        test2= benefactorData_find("87654321K", benefactorData);
        test3= benefactorData_find("57489321B", benefactorData);

        t1 = strcmp(test2->person->document, "87654321K");
        t2 = strcmp(test3->person->document, "57489321B");

        if (test1 == NULL && !t1 && !t2) {
            testPassed= true;
        }

        test1=NULL;
        test2=NULL;
        test3=NULL;


        t1 = false;
        t2 = false;
        t3 = false;
    
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX1_F", testPassed);


	/////////////////////////////
	/////  PR2 EX1 TEST G  //////
	/////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_G", "Total amount of donations");
	
    if (!fail_all) {
        benefactorData.elems[0].totalAmount = am1;
        benefactorData.elems[1].totalAmount = am2;
        benefactorData.elems[2].totalAmount = am3;

        total = benefactorData_TotalAmount(benefactorData);

        if (total == (am1+am2+am3)) {
            testPassed = true;
        }
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX1_G", testPassed);


	/////////////////////////////////
	/////  PR2 EX1 TEST NGO A  //////
	/////////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_NGO_A", "Initialize NGO's Benefactors");
	tNGO ngo;
    
    ngo.benefactors.elems = (void*)23;
    ngo.benefactors.count = -1;
	ngo_init(&ngo, "XTP001", "To Xamogelo toy paidioy");
	if(ngo.benefactors.elems == NULL && ngo.benefactors.count == 0) {
		testPassed = true;
	}
    fail_all = !testPassed || fail_all;
    ngo_free(&ngo);

	end_test(test_section, "PR2_EX1_NGO_A", testPassed);


	/////////////////////////////////
	/////  PR2 EX1 TEST NGO B  //////
	/////////////////////////////////
	testPassed = false;
	start_test(test_section, "PR2_EX1_NGO_B", "Free NGO's Benefactors");
    if (!fail_all) {        
        if(ngo.benefactors.elems == NULL && ngo.benefactors.count == 0) {
            testPassed = true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }

	end_test(test_section, "PR2_EX1_NGO_B", testPassed);
    
    benefactorData_free(&benefactorData);
    free_test_people();

	return exercisePassed;

}

//Run all tests for Exercice 2 of PR2
bool run_pr2_ex2(tTestSection* test_section, const char* input)
{	
	tBenefactor benefactor1; // test data
	tBenefactor benefactor2; // test data
	tBenefactor benefactor3; // test data
	tBenefactor *test1, *test2, *test3; // helpers for comparisons
	tError terr1=E_NOT_IMPLEMENTED, terr2=E_NOT_IMPLEMENTED, terr3=E_NOT_IMPLEMENTED;
	tCallQueue emptyQueue;
	tNGO testNGO;
	bool exercisePassed = true;
	bool testPassed = false; // determines if test is passed or not
	bool t1=false, t2=false, t3=false; // helpers for comparison
	bool fail_all = false;

	//creates test data
	aux_pr2_ex1_initialize_benefactors(&benefactor1, &benefactor2, &benefactor3);

	tCallQueue queue;
	tError e1;

	/////////////////////////////
	/////  PR2 EX2 TEST A  //////
	/////////////////////////////    
	start_test(test_section, "PR2_EX2_A", "Initialize callQueue");


	e1=callQueue_create(&queue);
	t1=(e1 == E_SUCCESS);
	if(t1 && queue.first == NULL && queue.last==NULL) {
		testPassed=true;
	}

	t1=false;
	e1=E_NOT_IMPLEMENTED;
	end_test(test_section, "PR2_EX2_A", testPassed);
    
    // Fail other tests if this fails to avoid memory leaks
    fail_all = !testPassed;

	/////////////////////////////
	/////  PR2 EX2 TEST B  //////
	/////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_B", "Check emptiness of tCallQueue");

    if (!fail_all) {
        testPassed=callQueue_empty(&queue);
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }

	end_test(test_section, "PR2_EX2_B", testPassed);

	/////////////////////////////
	/////  PR2 EX2 TEST C  //////
	/////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_C", "Add Benefactor to CallQueue");

    if (!fail_all) {
        terr1=callQueue_enqueue(&benefactor1, &queue);
        terr2=callQueue_enqueue(&benefactor2, &queue);
        terr3=callQueue_enqueue(&benefactor3, &queue);
        test1 = queue.first->benefactor;
        test2 = queue.first->next->benefactor;
        test3 = queue.last->benefactor;

        t1=strcmp(test1->person->document,benefactor1.person->document);
        t2=strcmp(test2->person->document,benefactor2.person->document);
        t3=strcmp(test3->person->document,benefactor3.person->document);

        if(!t1 && !t2 && !t3 &&
           terr1==E_SUCCESS && terr2 ==E_SUCCESS && terr3==E_SUCCESS) {
            testPassed= true;
        }
        t1=t2=t3=false;
        terr1=terr2=terr3=E_NOT_IMPLEMENTED;
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX2_C", testPassed);

	/////////////////////////////
	/////  PR2 EX2 TEST D  //////
	/////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_D", "Get Queue Head");
    
    if (!fail_all) {

        //gets from existing queue to checks the head is returned
        test1=callQueue_head(&queue);
        //create an empty list to check for null
        e1=callQueue_create(&emptyQueue);

        t1=strcmp(test1->person->document,benefactor1.person->document);
        t2=(callQueue_head(&emptyQueue)==NULL);
        if(!t1 && t2) {
            testPassed=true;
        }
        t1=t2=false;
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX2_D", testPassed);

	/////////////////////////////
	/////  PR2 EX2 TEST E  //////
	/////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_E", "Get and Remove Queue Head");
	//testing what remains in the queue, it could also be tested what has been returned

    if (!fail_all) {
        test1 = callQueue_dequeue(&queue);
        t1=strcmp(queue.first->benefactor->person->document,benefactor2.person->document);

        test2 = callQueue_dequeue(&queue);
        t2=strcmp(queue.first->benefactor->person->document,benefactor3.person->document);

        test3 = callQueue_dequeue(&queue);
        test3 = callQueue_dequeue(&queue);


        if(!t1 && !t2 && test3 ==NULL) {
            testPassed=true;
        }

        t1=t2=false;
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX2_E", testPassed);

	/////////////////////////////
	/////  PR2 EX2 TEST F  //////
	/////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_F", "Free Queue");

    if (!fail_all) {
        //callQueue_free(&queue);
        terr1=callQueue_enqueue(&benefactor1, &queue);
        terr2=callQueue_enqueue(&benefactor2, &queue);
        terr3=callQueue_enqueue(&benefactor3, &queue);
        callQueue_free(&queue);

        if(queue.first ==NULL && queue.last ==NULL) {
            testPassed=true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }

	end_test(test_section, "PR2_EX2_F", testPassed);

	/////////////////////////////////
	/////  PR2 EX2 TEST NGO A  //////
	/////////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_NGO_A", "Initialize NGO's tCallQueue");

    if (!fail_all) {
        ngo_init(&(testNGO),"XTP001", "To Xamogelo toy paidioy");
        if(testNGO.calls.first == NULL && testNGO.calls.last ==NULL) {
            testPassed = true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }

	end_test(test_section, "PR2_EX2_NGO_A", testPassed);


	//////////////////////////////////
	/////  PR2 EX2 TEST BGO B  //////
	/////////////////////////////////    
	testPassed=false;
	start_test(test_section, "PR2_EX2_NGO_B", "Free NGO's tCallQueue");
    
    if (!fail_all) {

        terr1=callQueue_enqueue(&benefactor1, &testNGO.calls);
        terr2=callQueue_enqueue(&benefactor2, &testNGO.calls);
        terr3=callQueue_enqueue(&benefactor3, &testNGO.calls);
        ngo_free(&(testNGO));
        if(testNGO.calls.first == NULL && testNGO.calls.last==NULL) {
            testPassed=true;
        }
        
    }
	end_test(test_section, "PR2_EX2_NGO_B", testPassed);

	benefactor_free(&benefactor1);
	benefactor_free(&benefactor2);
	benefactor_free(&benefactor3);
    
    free_test_people();
    
    return exercisePassed;
}

//Run all tests for Exercice 3 of PR2
bool run_pr2_ex3(tTestSection* test_section, const char* input)
{
	tError error=E_NOT_IMPLEMENTED;
	tNGO *pNGO;
	tApiData data;
	tCSVEntry donation, donor;
	float totalDonations;
	char *personEntry;
	bool exercisePassed = true;
	bool testPassed = false; // determines if test is passed or not
    bool fail_all = false;

	
	/////////////////////////////
	/////  PR2 EX3 TEST A  //////
	/////////////////////////////    

	start_test(test_section, "PR2_EX3_A", "API Add Donation");
    csv_initEntry(&donor);
    csv_parseEntry(&donor, "X6408356G;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980","PERSON");
	csv_initEntry(&donation);	
	csv_parseEntry(&donation, "F03/04/2022;X6408356G;FESBAL;Spanish Federation of Food Banks;MADRID;2500.50", "DONATION");	
	error=api_initData(&data);
    error = api_addPerson(&data, donor);
    if (error == E_SUCCESS) {
        error = api_addDonation(&data, donation);
        if (error == E_SUCCESS && data.NGOs.count == 1 && data.people.count == 1 && data.NGOs.first != NULL) {            
            testPassed=true;
        }    
    }
	csv_freeEntry(&donation);	
    csv_freeEntry(&donor);
    
    // Fail other tests if this fails to avoid memory leaks
    fail_all = !testPassed;

	end_test(test_section, "PR2_EX3_A", testPassed);
	
	/////////////////////////////
	/////  PR2 EX3 TEST B  //////
	/////////////////////////////    
	testPassed = false;
	start_test(test_section, "PR2_EX3_B", "API Add Call to CallQueue");
	
    if (!fail_all) {        
        pNGO = &(data.NGOs.first->elem);
        error = api_ngoAddCall("X6408356G", pNGO); 
        if(error == E_SUCCESS && pNGO->calls.first != NULL && 
            !strcmp(pNGO->calls.first->benefactor->person->document, "X6408356G")){
            testPassed=true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
        
	end_test(test_section, "PR2_EX3_B", testPassed);
	
	/////////////////////////////
	/////  PR2 EX3 TEST C  //////
	/////////////////////////////    
	testPassed = false;
	start_test(test_section, "PR2_EX3_C", "API Make Call");
	
    if (!fail_all) {
        pNGO = &(data.NGOs.first->elem);
        personEntry = api_ngoMakeCall(pNGO);
        
        csv_initEntry(&donor);
        csv_parseEntry(&donor, personEntry, "PERSON");        
        if(personEntry!= NULL && !strcmp(donor.fields[0], "X6408356G")) {            
            testPassed=true;
        }
        csv_freeEntry(&donor);        
        free(personEntry);
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }

	end_test(test_section, "PR2_EX3_C", testPassed);

	
	/////////////////////////////
	/////  PR2 EX3 TEST D  //////
	/////////////////////////////    
	testPassed = false;
	start_test(test_section, "PR2_EX3_D", "API Total Amount Donations");    
    api_loadData(&data, input, true);
    if (!fail_all) {
        
        totalDonations = api_ngoIncome(data, "FESBAL");
        if (totalDonations == 1005001) {
            testPassed=true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR2_EX3_D", testPassed);
	
	/////////////////////////////
	/////  PR2 EX3 TEST E  //////
	/////////////////////////////    
	testPassed = false;
	start_test(test_section, "PR2_EX3_E", "API NGO Project Count");
	
    if (!fail_all) {
        int projectCount = api_ngoProjectCount(data,"FESBAL");
        if(projectCount == 2){
            testPassed=true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	
	end_test(test_section, "PR2_EX3_E", testPassed);
    
    api_freeData(&data);
	
	return exercisePassed;
}
