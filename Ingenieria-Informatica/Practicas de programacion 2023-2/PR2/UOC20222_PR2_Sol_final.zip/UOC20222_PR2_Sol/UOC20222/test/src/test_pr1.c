#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr1.h"
#include "api.h"

// Run all tests for PR1
bool run_pr1(tTestSuite* test_suite, const char* input) {
    bool ok = true;
    tTestSection* section = NULL;

    assert(test_suite != NULL);

    testSuite_addSection(test_suite, "PR1", "Tests for PR1 exercises");

    section = testSuite_getSection(test_suite, "PR1");
    assert(section != NULL);

    ok = run_pr1_ex1(section, input);
    ok = run_pr1_ex2(section, input) && ok;
    ok = run_pr1_ex3(section, input) && ok;

    return ok;
}

// Run all tests for Exercice 1 of PR1
bool run_pr1_ex1(tTestSection* test_section, const char* input) {
    bool passed = true, failed = false;
    const char* version;
    
    /////////////////////////////
    /////  PR1 EX1 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX1_1", "Read version information.");
    // Get the version
    version = api_version();
    if (strcmp(version, "UOC PP 20222") != 0) {
        failed = true;
        passed = false;
    }
    end_test(test_section, "PR1_EX1_1", !failed);
    
    return passed;
}

// Run all tests for Exercice 2 of PR1
bool run_pr1_ex2(tTestSection* test_section, const char* input) {
    tApiData data;
    tError error;
    tCSVEntry donation, entry;    
	float budget;
    int numberNGOs, numberProjects, numberPeople;
    bool passed = true;
    bool failed = false;
    bool fail_all = false;
    
    /////////////////////////////
    /////  PR1 EX2 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_1", "Initialize the API data structure");
    // Initialize the data    
    error = api_initData(&data);
    if (error != E_SUCCESS) {
        failed = true;
        passed = false;
        fail_all = true;
    }
    end_test(test_section, "PR1_EX2_1", !failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 2  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_2", "Add a valid donation");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);	
        csv_parseEntry(&entry, "X6408356G;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980","PERSON");
        error = api_addPerson(&data, entry);   
        csv_freeEntry(&entry);
		
		csv_initEntry(&donation);		
		csv_parseEntry(&donation, "02/03/2022;X6408356G;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;2500.00", "DONATION");		
        error = api_addDonation(&data, donation);
        if (error != E_SUCCESS) {
            failed = true;
            passed = false;
            fail_all = true;
        }
		csv_freeEntry(&donation);	        
    }
    end_test(test_section, "PR1_EX2_2", !failed);
           
    /////////////////////////////
    /////  PR1 EX2 TEST 3  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_3", "Check the number of NGOs and projects");
    if (fail_all) {
        failed = true;
    } else {
        numberNGOs = api_ngoCount(data);    		
		numberProjects =  api_projectCount(data);  
        if (numberNGOs != 1 || numberProjects != 1) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    }
    end_test(test_section, "PR1_EX2_3", !failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 4  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_4", "Check the if the budget has been updated");
    if (fail_all) {
        failed = true;
    } else {        
        budget = api_ngoProjectBudget(data,"FOOD_BANK_BCN","BARCELONA");
        if (budget != 2500.0) {
            failed = true;
            passed = false;
            fail_all = true;
        }  
		csv_initEntry(&donation);		
		csv_parseEntry(&donation, "02/03/2022;X6408356G;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;1500.50", "DONATION");		
        error = api_addDonation(&data, donation);
        if (error != E_SUCCESS) {
            failed = true;
            passed = false;
            fail_all = true;
        }
		csv_freeEntry(&donation);		
		budget = api_ngoProjectBudget(data,"FOOD_BANK_BCN","BARCELONA");
        if (budget != 4000.50) {
            failed = true;
            passed = false;
            fail_all = true;
        } 
    }
	
	
	
    end_test(test_section, "PR1_EX2_4", !failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 5  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_5", "Add a donation with invalid type");    
    if (fail_all) {
        failed = true;
    } else {
		csv_freeEntry(&donation);
        csv_parseEntry(&donation, "03/04/2022;X6408356G;FESBAL;Spanish Federation of Food Banks;MADRID;2500.00", "DONATION_NGO");		
        error = api_addDonation(&data, donation);
        if (error != E_INVALID_ENTRY_TYPE) {
            failed = true;
            passed = false;
        }
        csv_freeEntry(&donation);		
    }
    end_test(test_section, "PR1_EX2_5", !failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 6  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_6", "Add a donation with invalid fields");    
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&donation);
        csv_parseEntry(&donation, "20/09/2022;X6408356G;YMCA;Young Mens Christian Association;NEW_YORK;5000.00;extra field", "DONATION");		
        error = api_addDonation(&data, donation);
        if (error != E_INVALID_ENTRY_FORMAT) {
            failed = true;
            passed = false;
        }
        csv_freeEntry(&donation);		
    }
    end_test(test_section, "PR1_EX2_6", !failed);
	
	 /////////////////////////////
    /////  PR1 EX2 TEST 7  //////
    /////////////////////////////    
    failed = false;
    start_test(test_section, "PR1_EX2_7", "Add people as donors and check format");    
    if (fail_all) {
        failed = true;
    } else {
        api_freeData(&data);
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "87654321K;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980", "PERSON");
        error = api_addPerson(&data, entry);
        if (error != E_SUCCESS) {
            failed = true;
            passed = false;
        }
		csv_freeEntry(&entry);
		
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985", "PEOPLE");
        error = api_addPerson(&data, entry);
        if (error != E_INVALID_ENTRY_TYPE) {
            failed = true;
            passed = false;
        }
		csv_freeEntry(&entry);
		
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985;extra field", "PERSON");
        error = api_addPerson(&data, entry);
        if (error != E_INVALID_ENTRY_FORMAT) {
            failed = true;
            passed = false;
        }
		csv_freeEntry(&entry);
		
        csv_initEntry(&entry);
        csv_parseEntry(&entry, "Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985","PERSON");  
        error = api_addPerson(&data, entry);    	
		csv_freeEntry(&entry);

		numberPeople = api_peopleCount(data);    	
		
        if (numberPeople != 2) {
            failed = true;
            passed = false;
            fail_all = true;
        }   
		
		csv_initEntry(&entry);
        csv_parseEntry(&entry, "Y3168793M;Alice;Jones;alice.jones@example.com;Other street, 11;+2-100-444-1234;28/02/1992", "PERSON");
        error = api_addPerson(&data, entry);        
		csv_freeEntry(&entry);
		
		numberPeople = api_peopleCount(data);    	

		if (numberPeople != 3) {
            failed = true;
            passed = false;
            fail_all = true;
        }
    }
    end_test(test_section, "PR1_EX2_7", !failed);
    
    /////////////////////////////
    /////  PR1 EX2 TEST 8  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_8", "Free API data");    
    if (fail_all) {
        failed = true;
    } else {        
        error = api_freeData(&data);
        numberNGOs = api_ngoCount(data);
        numberPeople = api_peopleCount(data);
        if (error != E_SUCCESS || numberNGOs != 0  || numberPeople != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    }
    end_test(test_section, "PR1_EX2_8", !failed);
    
    
    /////////////////////////////
    /////  PR1 EX2 TEST 9  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_9", "Load data from file");
    // Load basic data to the API
    if (fail_all) {
        failed = true;
    } else {
        error = api_loadData(&data, input, true);
        numberNGOs = api_ngoCount(data);
		numberPeople = api_peopleCount(data);
		numberProjects =  api_projectCount(data); 
        if (error != E_SUCCESS || numberNGOs != 3 || numberPeople != 3 || numberProjects != 3) {
            failed = true;
            passed = false;
        }
    }
    end_test(test_section, "PR1_EX2_9", !failed);
    
    // Release all data
    api_freeData(&data);
    
    return passed;
}


// Run all tests for Exercice 3 of PR1
bool run_pr1_ex3(tTestSection* test_section, const char* input) {
    tApiData data;
    tError error;
    tCSVEntry entry;
    tCSVEntry refEntry;
    tCSVData report;
    tCSVData refReport;
    int numberNGOs, numberPeople, numberProjects;
    bool passed = true;
    bool failed = false;
    bool fail_all = false;
    
    
    // Initialize the data    
    error = api_initData(&data);
    if (error != E_SUCCESS) {        
        passed = false;        
        fail_all = true;
    }
    
    if (!fail_all) {
        error = api_loadData(&data, input, true);
		numberNGOs = api_ngoCount(data);
		numberPeople = api_peopleCount(data);
		numberProjects =  api_projectCount(data); 
        if (error != E_SUCCESS || numberNGOs != 3 || numberPeople != 3 || numberProjects != 3) {         
            passed = false;
            fail_all = true;
        }
    }
    
    
    /////////////////////////////
    /////  PR1 EX3 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_1", "Request a valid NGO");
    if (fail_all) {
        failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
        csv_parseEntry(&refEntry, "WCK;World Central Kitchen", "NGO");
        error = api_getNGO(data, "WCK", &entry);
        if (error != E_SUCCESS || !csv_equalsEntry(entry, refEntry)) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_1", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 2  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_2", "Request a missing NGO");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        error = api_getNGO(data, "YMCA", &entry);
        if (error != E_NOT_FOUND) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);        
    }
    end_test(test_section, "PR1_EX3_2", !failed);
           
    /////////////////////////////
    /////  PR1 EX3 TEST 3  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_3", "Request a valid project");
    if (fail_all) {
        failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
        csv_parseEntry(&refEntry, "UKRANIE;WCK;1000000.00", "PROJECT");
        error = api_getProject(data, "WCK", "UKRANIE", &entry);
        if (error != E_SUCCESS || !csv_equalsEntry(entry, refEntry)) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_3", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 4  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_4", "Request a missing Project");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&refEntry, "SWITZERLAND;WCK;10000.00", "PROJECT");
        error = api_getProject(data, "WCK", "SWITZERLAND", &entry);
        if (error != E_NOT_FOUND) {
            failed = true;
            passed = false;            
        }        
        csv_freeEntry(&entry);
		csv_freeEntry(&refEntry);
		
    }
    end_test(test_section, "PR1_EX3_4", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 5  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_5", "Request a project from a missing NGO");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
		csv_parseEntry(&refEntry, "UKRANIE;YMCA;1000000.00", "PROJECT");
        error = api_getProject(data, "YMCA", "UKRANIE", &entry);
        if (error != E_NOT_FOUND) {
            failed = true;
            passed = false;            
        }        
        csv_freeEntry(&entry);
		csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_5", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 6  //////
    /////////////////////////////
	
    failed = false;
    start_test(test_section, "PR1_EX3_6", "Get registered NGOs");
    if (fail_all) {
        failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);	
		csv_addStrEntry(&refReport, "FESBAL;Spanish Federation of Food Banks", "NGO");
		csv_addStrEntry(&refReport, "WCK;World Central Kitchen", "NGO");
        csv_addStrEntry(&refReport, "FOOD_BANK_BCN;Food Bank from Barcelona", "NGO");
        error = api_getNGOs(data, &report);
        if (error != E_SUCCESS || !csv_equals(report, refReport)) {
            failed = true;
            passed = false;            
        }  
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_6", !failed);
	
	 /////////////////////////////
    /////  PR1 EX3 TEST 7  //////
    /////////////////////////////
	
    failed = false;
    start_test(test_section, "PR1_EX3_7", "Get registered Projects");
    if (fail_all) {
        failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);	
		csv_addStrEntry(&refReport, "MADRID;FESBAL;502500.50", "PROJECT");
		csv_addStrEntry(&refReport, "UKRANIE;WCK;1000000.00", "PROJECT");
		csv_addStrEntry(&refReport, "BARCELONA;FOOD_BANK_BCN;5000.00", "PROJECT");
        error = api_getProjects(data, &report);
        if (error != E_SUCCESS || !csv_equals(report, refReport)) {
            failed = true;
            passed = false;            
        }  
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_7", !failed);
    
    // Release all data
    api_freeData(&data);
    
    return passed;
}
