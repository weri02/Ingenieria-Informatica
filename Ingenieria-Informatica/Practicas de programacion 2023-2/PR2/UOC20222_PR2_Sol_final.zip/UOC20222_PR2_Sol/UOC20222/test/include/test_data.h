#ifndef __TEST_DATA__H
#define __TEST_DATA__H

// Define test data for PR1
const char* test_data_pr1_str = "PERSON;X6408356G;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980\n" \
								"PERSON;Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985\n" \
								"PERSON;Y3168793M;Alice;Jones;alice.jones@example.com;Other street, 11;+2-100-444-1234;28/02/1992\n" \
								"DONATION;02/03/2022;X6408356G;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;5000.00;\n" \
								"DONATION;03/04/2022;X6408356G;FESBAL;Spanish Federation of Food Banks;MADRID;2500.50\n" \
								"DONATION;05/06/2022;Z5446375A;FESBAL;Spanish Federation of Food Banks;MADRID;500000.00\n" \
								"DONATION;07/08/2022;Y3168793M;WCK;World Central Kitchen;UKRANIE;1000000.00\n";  

// Define test data for PR1
const char* test_data_pr2_str = "PERSON;X6408356G;John;Smith;john.smith@example.com;My street, 25;+1-202-555-0145;30/12/1980\n" \
								"PERSON;Z5446375A;Bob;Williams;bob.williams@example.com;My boulevar, 1;+5-313-777-1234;01/01/1985\n" \
								"PERSON;Y3168793M;Alice;Jones;alice.jones@example.com;Other street, 11;+2-100-444-1234;28/02/1992\n" \
								"PERSON;B7843746J;Jane;Doe;jane.doe@example.com;Some street, 12;+3-222-333-1234;15/05/1982\n" \
								"PERSON;C8982734F;James;Bond;james.bond@example.com;Another street, 22;+4-444-555-1234;20/08/1984\n" \
								"PERSON;D7658493G;Sarah;Johnson;sarah.johnson@example.com;A different street, 33;+5-666-777-1234;17/11/1988\n" \
								"PERSON;E1478523K;Mark;Taylor;mark.taylor@example.com;New street, 44;+6-888-999-1234;22/03/1990\n" \
								"PERSON;F9632587L;Kate;Williams;kate.williams@example.com;Last street, 55;+7-111-222-1234;29/06/1993\n" \
								"PERSON;G1245369M;Michael;Brown;michael.brown@example.com;One more street, 66;+8-333-444-1234;12/09/1996\n" \
								"DONATION;02/03/2022;X6408356G;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;5000.00;\n" \
								"DONATION;03/04/2022;X6408356G;FESBAL;Spanish Federation of Food Banks;MADRID;2500.50\n" \
								"DONATION;05/06/2022;Z5446375A;FESBAL;Spanish Federation of Food Banks;UKRANIE;500000.00\n" \
								"DONATION;07/08/2022;X6408356G;FOOD_BANK_BCN;Food Bank from Barcelona;BARCELONA;5000.00;\n" \
								"DONATION;09/10/2022;X6408356G;FESBAL;Spanish Federation of Food Banks;MADRID;2500.50\n" \
								"DONATION;10/11/2022;Z5446375A;FESBAL;Spanish Federation of Food Banks;MADRID;500000.00\n" \
								"DONATION;07/08/2022;Y3168793M;WCK;World Central Kitchen;UKRANIE;1000000.00\n" \
								"DONATION;09/10/2022;B7843746J;CFR;Children's Food Relief;USA;150000.00\n" \
								"DONATION;11/12/2022;C8982734F;AMF;Against Malaria Foundation;GERMANY;200000.00\n" \
								"DONATION;01/02/2023;D7658493G;WFP;World Food Programme;FRANCE;250000.00\n" \
								"DONATION;03/04/2022;E1478523K;CFR;Children's Food Relief;USA;100000.00\n" \
								"DONATION;05/06/2022;F9632587L;AMF;Against Malaria Foundation;GERMANY;150000.00\n" \
								"DONATION;07/08/2022;G1245369M;WFP;World Food Programme;FRANCE;200000.00\n";                          
                      
#endif // TEST_DATA__H
