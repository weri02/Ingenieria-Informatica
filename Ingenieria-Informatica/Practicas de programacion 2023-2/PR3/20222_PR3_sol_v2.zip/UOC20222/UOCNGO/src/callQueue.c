#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "error.h"
#include "callQueue.h"



tError callQueue_create(tCallQueue *queue){
	/////////////////////////////
	/////  PR2 EX2 A  ///////////
	/////////////////////////////  	
    
    assert(queue != NULL);
	queue->first=NULL;
	queue->last=NULL;

	return E_SUCCESS;    
	//return E_NOT_IMPLEMENTED;
	
}

void callQueue_free(tCallQueue *queue){
	/////////////////////////////
	/////  PR2 EX2 F  ///////////
	///////////////////////////// 	
    tCallNode *tmp = queue->first;

	while (tmp != NULL) {
		tmp=tmp->next;
		callNode_delete(queue->first,queue);
	}

}

bool callQueue_empty(tCallQueue *queue){
	
	/////////////////////////////
	/////  PR2 EX2 B  //////
	/////////////////////////////  	
    assert (queue !=NULL);
	return (queue->first == NULL && queue->last == NULL);

	//return false;
}

tError callQueue_enqueue(tBenefactor *benefactor, tCallQueue *queue){
	/////////////////////////////
	/////  PR2 EX2 C  ///////////
	/////////////////////////////  	
    tCallNode *node = (tCallNode*) malloc(sizeof(tCallNode));
	node->benefactor=benefactor;
    node->next=NULL;
	if(queue->first == NULL){
        queue->first = node;		
	} else {
		queue->last->next = node;
	}
	queue->last=node;
	return E_SUCCESS;

	//return E_NOT_IMPLEMENTED;
}

tBenefactor* callQueue_head(tCallQueue *queue){
	/////////////////////////////
	/////  PR2 EX2 D  ///////////
	/////////////////////////////  	
    assert (queue != NULL);
	if(queue->first != NULL){
		return queue->first->benefactor;
	}
	return NULL;

	//return NULL;
}

tBenefactor* callQueue_dequeue(tCallQueue *queue){
	/////////////////////////////
	/////  PR2 EX2 E  ///////////
	/////////////////////////////      
    tCallNode *tmp = queue->first;
    tBenefactor *data;

    if (queue->first == NULL) {
        data = NULL;
    } else if (queue->first == queue->last) {
        queue->first = queue->last = NULL;
        data = tmp->benefactor;
        free(tmp);
    } else {
	
        queue->first = tmp->next;
        data = tmp->benefactor;
        free(tmp);
    }
    return data;
    
    //return NULL;
}


//[[AUX]]  deletes a node from the call queue
void callNode_delete(tCallNode *node, tCallQueue *list){
 	/////////////////////////////
	/////  PR2 EX2 F  ///////////
	/////////////////////////////    
	if (node == list->first) {
        if (list->first->next == NULL) { 
            list->first = list->last = NULL;
        } else {
            list->first = list->first->next;
        }
    } else {
        tCallNode *tmp = list->first;
        while (tmp != NULL && tmp->next != node) {
            tmp = tmp->next;
        }
        if (tmp != NULL) {
            tmp->next = node->next;
        } 
    }
    free(node);
}
