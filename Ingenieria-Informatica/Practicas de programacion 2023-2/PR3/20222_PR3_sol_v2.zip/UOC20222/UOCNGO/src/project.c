#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "project.h"
#include "error.h"


// Initialize project 
void project_init(tProject* project, const char* code, const char* ngo, float budget){
    assert(project != NULL);
    assert(code != NULL);
    assert(ngo != NULL);
    

    // Allocate memory for the code
    project->code = (char*) malloc(strlen(code) + 1);
    assert(project->code != NULL);
	strcpy(project->code, code); 
	
    // Allocate memory for the ngo
    project->ngoCode = (char*) malloc(strlen(ngo) + 1);
    assert(project->ngoCode != NULL);
	strcpy(project->ngoCode, ngo); 
	
    // Set the budget
    project->budget = budget;   
}


// Release project list
void project_free(tProject* project) {
    assert(project != NULL);
    
    // Release used memory
    if (project->code != NULL) {
        free(project->code);
        project->code = NULL;
    }
    if (project->ngoCode != NULL) {
        free(project->ngoCode);
        project->ngoCode = NULL;
    }
    project->budget = 0.0;

}

// Copy the element of a project from the source to destination
void project_cpy(tProject* destination, tProject source) {
    assert(destination != NULL);

    // Set the element
    project_init(destination, source.code, source.ngoCode, source.budget);
}

void project_parse(tProject* project, tCSVEntry entry){
	char *code;
    char *ngoCode;
	float budget;
	int indCode=0, indOngCode=1, indBudget=2;
    
    // Check input data
    assert(project != NULL);
    
    // Check entry fields
    assert(csv_numFields(entry) == 3 || csv_numFields(entry) == 6);
	
	if (strcmp(csv_getType(&entry), "DONATION") == 0) {
        indCode = 4;
		indOngCode = 2;
		indBudget = 5;
    }
         
    // Copy  project code
    code = (char*) malloc((strlen(entry.fields[indCode]) + 1) * sizeof(char));
    assert(code != NULL);
    csv_getAsString(entry, indCode, code, strlen(entry.fields[indCode]) + 1);
    
    // Copy NGO code
    ngoCode = (char*) malloc((strlen(entry.fields[indOngCode]) + 1) * sizeof(char));
    assert(ngoCode != NULL);
    csv_getAsString(entry, indOngCode, ngoCode, strlen(entry.fields[indOngCode]) + 1);
    
	// Copy budget code
    budget = csv_getAsReal(entry, indBudget);
	
    // Initialize the project with entry data
    project_init(project, code, ngoCode, budget);
    
    // Remove temporal fields
    free(code);
    free(ngoCode);
	}

// Initialize the project element
void projectList_init(tProjectList* list) {
   	 assert(list != NULL);
    
     list->first = NULL;
     list->count = 0;
}

// Remove all elements
void projectList_free(tProjectList* list) {
	tProjectNode *pNode = NULL;
    tProjectNode *pAux = NULL;
    
    assert(list != NULL);
    
    pNode = list->first;
    while(pNode != NULL) {
        // Store the position of the current node
        pAux = pNode;
        
        // Move to the next node in the list
        pNode = pNode->next;
        
        // Remove previous node
        project_free(&(pAux->elem));
        free(pAux);
    }
    
    // Initialize to an empty list
    projectList_init(list);
}

int projectList_len(tProjectList list) {
    // Return the number of projects
    return list.count;
}

// Insert a new project
void projectList_insert(tProjectList* list, const char* projectCode, const char* ngoCode, float budget) {
	tProjectNode *pNode;
    tProjectNode *pAux;
    
    assert(list != NULL);
    assert(projectCode != NULL);
	assert(ngoCode != NULL);
    
    if (projectList_find(list, projectCode) == NULL) {    
        
        // Check if insertion point is the first position
        if (list->first == NULL || strcmp(list->first->elem.code, projectCode) > 0) {
            // Insert as initial position
            pAux = list->first;            
            list->first = (tProjectNode*) malloc(sizeof(tProjectNode));
            assert(list->first != NULL);
            list->first->next = pAux;
            project_init(&(list->first->elem), projectCode, ngoCode, budget);
        } else {        
            // Search insertion point
            pAux = list->first;
            pNode = pAux->next;            
            while(pNode != NULL && strcmp(pNode->elem.code, projectCode) > 0) {                
                pAux = pNode;
                pNode = pNode->next;         
            }
            pAux->next = (tProjectNode*) malloc(sizeof(tProjectNode));
            assert(pAux->next != NULL);
            pAux->next->next = pNode;          
			project_init(&(pAux->next->elem), projectCode, ngoCode, budget);

        }
        // Increase the number of elements
        list->count++;
    }
	

}


// Remove project list elemeny
void projectList_del(tProjectList* list, const char* code) {
    tProjectNode *pNode = NULL;
    tProjectNode *pPrev = NULL;
    
    assert(list != NULL);
    
    // Check if the list has elements
    if (list->count > 0) {
        pNode = list->first;
        
        // Check if we are removing the first position
        if (strcmp(pNode->elem.code, code) == 0) {
            list->first = pNode->next;
        } else {    
            // Search in the list
            pPrev = pNode;
            while (pNode != NULL) {                
                if (strcmp(pNode->elem.code, code) == 0) {
                    // Link previous and next nodes
                    pPrev->next = pNode->next;
                    // Remove node
                    project_free(&(pNode->elem));
                    free(pNode);
                    list->count --;                    
                    pNode = NULL;
                } else {
                    pPrev = pNode;
                    pNode = pNode->next;
                }                
            }            
        }            
    }

}



// Find a project
tProject* projectList_find(tProjectList* list, const char* code) {
	 
	tProjectNode *pNode;    
    tProject *pProject;    
    
    assert(list != NULL);
    
    // Search center with provided code
    pNode = list->first;
    pProject = NULL;
    while(pNode != NULL && pProject == NULL) {
        if(strcmp(code, pNode->elem.code) == 0) {
            pProject = &(pNode->elem);
        }        
        pNode = pNode->next;        
    }
    
    return pProject;

}


// Find the project with the highest budget
tProject* projectList_findMostValuable(tProjectList* list) {
    //////////////////////////////////
	// Ex PR3 2b
	/////////////////////////////////
    float maxValue = -1;
    tProject *mvp = NULL;
    tProjectNode* node = NULL;
    
    // Check the list
    assert(list != NULL);
    
    node = list->first;
    // Traverse all projects
    while (node != NULL) {
        // Check if current project has a bigger budget than the current most valuable one
        if (node->elem.budget > maxValue) {
            // Update the most valuable
            maxValue = node->elem.budget;
            mvp = &(node->elem);
        }
        // Move to next node
        node = node->next;        
    }
    
    return mvp;
    
    //return NULL;
}
