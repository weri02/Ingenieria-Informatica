#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "csv.h"
#include "project.h"
#include "person.h"
#include "ngo.h"
#include "benefactor.h"


void benefactor_init(tPerson *person, tBenefactor* data){
	// Check input data
    assert(data != NULL);
	data->person=person;
	data->totalAmount=0;
}

void benefactor_free(tBenefactor* data){
	// Check input data
    assert(data != NULL);	
	data->totalAmount=0;
}


tError benefactorData_init(tBenefactorData* data){
	////////////////////////////
	/////  PR2 EX1 A    ////////
	///////////////////////////// 	
    assert(data != NULL);
	data->elems=NULL;
	data->count=0;
    
	return E_SUCCESS;    
	//return E_NOT_IMPLEMENTED;
}

// Remove all data from Benefactors data structure
void benefactorData_free(tBenefactorData *data){
	assert(data != NULL);
	if(data->elems != NULL){
		free(data->elems);
		data->elems=NULL;
	}
	data->count=0;
}

int benefactorData_len(tBenefactorData data){
	////////////////////////////
	/////  PR2 EX1 B    //////
	///////////////////////////// 
    return data.count;
	//return -1;
}

tError benefactorData_add (tBenefactor* benefactor, tBenefactorData* data){
	////////////////////////////
	/////  PR2 EX1 C    //////
	///////////////////////////// 	
    assert(data != NULL);
	assert(benefactor != NULL);
	tError error;
	
	if(data->count == 0) {
		data->elems = (tBenefactor*) malloc(sizeof(tBenefactor));
	} else {
		if(findBenefactorInList(*benefactor, *data) == E_DUPLICATED_PERSON){
			return E_DUPLICATED_PERSON;
		}
		data->elems = (tBenefactor*) realloc(data->elems, sizeof(tBenefactor) * (data->count+1));
	}
	data->elems[data->count] = *benefactor;
	data->count = data->count +1;
	
	quicksort(data->elems, 0, data->count -1);
	return E_SUCCESS;

	//return E_NOT_IMPLEMENTED;
}

tBenefactor* benefactorData_get (int position, tBenefactorData data){
	////////////////////////////
	/////  PR2 EX1 D    //////
	///////////////////////////// 
    if( position < 0 || position >= data.count) {
		return NULL;
	} else {
		return (&data.elems[position]);
	}

	//return NULL;	
}

tError benefactorData_del(char *document, tBenefactorData *data){
	////////////////////////////
	/////  PR2 EX1 E    //////
	/////////////////////////////
    assert(data != NULL);
	assert (document != NULL);

	int pos;
    int i;
   
    // Find if it exists
    pos = findBenefactorPosInList(document, *data);
	
	if(pos == E_NOT_FOUND){
		return E_NOT_FOUND;
	}
   
    if (pos >= 0) {
        // Shift elements to remove selected
        for(i = pos; i < data->count-1; i++) {
            // Copy element on position i+1 to position i
            data->elems[i]=data->elems[i+1];
        }
        // Update the number of elements
        data->count--;
       
        // Resize the used memory
        if (data->count == 0) {
            // No element remaining
            free(data->elems);
            data->elems = NULL;
        } else {
            // Still some elements are remaining
            data->elems = (tBenefactor*)realloc(data->elems, data->count * sizeof(tBenefactor));
        }        
    }
	return E_SUCCESS;

	//return E_NOT_IMPLEMENTED;

}

tBenefactor* benefactorData_find (char *document, tBenefactorData data){
	////////////////////////////
	/////  PR2 EX1 F    //////
	/////////////////////////////	
    assert(document != NULL);
	tBenefactor *result ;
	int position = findBenefactorPosInList(document, data);
	
	if(position <0){
		return NULL;
	}
	result = (&data.elems[position]);
	return result;

	//return NULL;
}

float benefactorData_TotalAmount (tBenefactorData data){
	////////////////////////////
	/////  PR2 EX1 G    //////
	/////////////////////////////	
    assert( data.elems != NULL);
	float amount = 0.0;
	int i;
	
	for (i=0;i<data.count;i++){
		amount = amount + data.elems[i].totalAmount;
	}
	return amount;

	//return -1;
}


//////////////////////////////////////////////
/// Auxiliary methods
/////////////////////////////////////////////

//[AUX] Find Benefactor array position
int findBenefactorPosInList(char *document, tBenefactorData benefactorData){
	
	assert (document != NULL);
	int i, result;
	for (i=0;i<benefactorData.count;i++){
		result = strcmp(benefactorData.elems[i].person->document, document);
		if (result == 0){
			return i;
		}
	}
	return E_NOT_FOUND;
}


//[AUX] Find Person in Benefactors
tError findBenefactorInList(tBenefactor benefactor, tBenefactorData benefactorData){

	int i, result;
	for (i=0;i<benefactorData.count;i++){
		result = strcmp(benefactorData.elems[i].person->document, benefactor.person->document);
		if (result == 0){
			return E_DUPLICATED_PERSON;
		}
	}
	return E_NOT_FOUND;
}

// [AUX] Method performing quicksort
void quicksort(tBenefactor* people, int begin, int end) {    
    int i, j;
    tBenefactor pivot;
    tBenefactor aux;

    if (begin < end) {
        i = begin + 1;
        j = end;
        pivot = people[begin];

        while (i < j) {
            while (strcmp(people[i].person->document, pivot.person->document) < 0) {
                i++;
            }

            while (strcmp(people[j].person->document, pivot.person->document) > 0) {
                j--;
            }

            if (i < j) {
                // Swap positions
                aux = people[i];
                people[i] = people[j];
                people[j] = aux;                
            }
        }
        // Swap positions
        if (strcmp(people[begin].person->document, people[j].person->document) > 0) {
            aux = people[begin];
            people[begin] = people[j];
            people[j] = aux;            
        }
       
        quicksort(people, begin, j-1);
        quicksort(people, j+1, end);
    }
}
///////////////////////////////


// Search using binary search a benefactor in the list of benefactors
tBenefactor *benefactorData_findBS(char *code, tBenefactorData data) {
    //////////////////////////
	/////  PR3 EX1 A   ///////
	//////////////////////////
    int position;
    tBenefactor *benefactor = NULL;
    
    
    // Check input data
    assert(code != NULL);    
    
    // Use Binary Search to get the position
    position = benefactorData_binarySearch(data, 0, data.count, code);    
    if (position >= 0) {
        benefactor = (&data.elems[position]);
    }
    return benefactor;
    //return NULL;
}


// Sort list of benefactors by total money amount
tError benefactorData_SortByAmount(tBenefactorData src, tBenefactorData *dst) {
    ////////////////////////
	/////  PR3 EX2   ///////
	////////////////////////
    
    // Check output list
    assert(dst != NULL);    
    
    benefactorData_clone(src, dst);
    benefactorData_quicksort(dst, 0, src.count-1);
    return E_SUCCESS;

    //return E_NOT_IMPLEMENTED;
}

// [AUX] copy input list
void benefactorData_clone(tBenefactorData src, tBenefactorData *dst) {
    ////////////////////////
	/////  PR3 EX2   ///////
	////////////////////////    
    int i;
    
    // Check output list
    assert(dst != NULL);
    
    benefactorData_init(dst);
        
    for(i = 0; i < src.count; i++) {
        benefactorData_add(&(src.elems[i]), dst);
    }
}

// [AUX] quicksort using amount
void benefactorData_quicksort(tBenefactorData* benefactors, int begin, int end) {
    ////////////////////////
	/////  PR3 EX2   ///////
	////////////////////////
    int i, j;
    tBenefactor pivot;
    tBenefactor aux;
    
    // Check list
    assert(benefactors != NULL);    
    assert(begin >= 0);

    if (begin < end) {
        i = begin + 1;
        j = end;
        pivot = benefactors->elems[begin];

        while (i < j) {
            while (benefactors->elems[i].totalAmount > pivot.totalAmount) {
                i++;
            }

            while (benefactors->elems[j].totalAmount < pivot.totalAmount) {
                j--;
            }

            if (i < j) {
                // Swap positions
                aux = benefactors->elems[i];
                benefactors->elems[i] = benefactors->elems[j];
                benefactors->elems[j] = aux;                
            }
        }
        // Swap positions
        if (benefactors->elems[begin].totalAmount < benefactors->elems[j].totalAmount) {
            aux = benefactors->elems[begin];
            benefactors->elems[begin] = benefactors->elems[j];
            benefactors->elems[j] = aux;            
        }
       
        benefactorData_quicksort(benefactors, begin, j-1);
        benefactorData_quicksort(benefactors, j+1, end);
    }
}


// [AUX] binary search by document
int benefactorData_binarySearch(tBenefactorData benefactors, int first, int last, const char *value) {
    ////////////////////////
	/////  PR3 EX2   ///////
	////////////////////////
    int middle;    
    
    // Base case 0: Empty table
    if (benefactors.count == 0) {
        return -1;
    }
    
    if (first <= last) {
        // Recursive case
        middle = (first + last) / 2;
                
        if (!strcmp(benefactors.elems[middle].person->document, value)) {
            // Base case 2: The element we are searching is the middle one
            return middle;
        } else {
            if (strcmp(benefactors.elems[middle].person->document, value) < 0) {
                // Search the right half
                return benefactorData_binarySearch(benefactors, middle+1, last, value);
            } else {
                // Search the left half
                return benefactorData_binarySearch(benefactors, first, middle-1, value);
            }
        }
    }

    // Base case 1: Element not found
    return -1;
}
