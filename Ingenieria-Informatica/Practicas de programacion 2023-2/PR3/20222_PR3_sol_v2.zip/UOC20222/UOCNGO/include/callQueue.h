#ifndef __CALLQUEUE_H__
#define __CALLQUEUE_H__

#include <stdbool.h>
#include "error.h"
#include "benefactor.h"


typedef struct _tCallNode{	
	tBenefactor *benefactor;
	struct _tCallNode *next;
} tCallNode;

typedef struct _tCallQueue{	
	tCallNode *first;
	tCallNode *last;
} tCallQueue;

void callNode_create(tBenefactor benefactor, tCallNode *node);
void callNode_free(tCallNode *node);
tError callQueue_create(tCallQueue *queue);
void callQueue_free(tCallQueue *queue);
bool callQueue_empty(tCallQueue *queue);
tError callQueue_enqueue(tBenefactor *benefactor, tCallQueue *queue);
tBenefactor* callQueue_head(tCallQueue *queue);
tBenefactor* callQueue_dequeue(tCallQueue *queue);

//[[AUX]]  deletes a node from the call queue
void callNode_delete(tCallNode *node, tCallQueue *list);

#endif //__CALLQUEUE_H_