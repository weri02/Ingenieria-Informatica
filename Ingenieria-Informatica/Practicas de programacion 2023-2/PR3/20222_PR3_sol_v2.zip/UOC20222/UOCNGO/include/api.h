#ifndef __UOCNGO_API__H
#define __UOCNGO_API__H
#include <stdbool.h>
#include "error.h"
#include "csv.h"
#include "project.h"
#include "person.h"
#include "ngo.h"

// Define an error type
typedef enum _tError tError;

// Type that stores all the application data
typedef struct _ApiData
{
	////////////////////////////////
	// PR1 EX2a
	////////////////////////////////  
	tPeople people;
	// NGOs
	tNGOList NGOs;
	////////////////////////////////

}

tApiData;

// Get the API version information
const char *api_version();

// Load data from a CSV file. If reset is true, remove previous data
tError api_loadData(tApiData *data, const char *filename, bool reset);

// Add a new entry
tError api_addDataEntry(tApiData *data, tCSVEntry entry);

// Free all used memory
tError api_freeData(tApiData *data);

// Initialize the data structure
tError api_initData(tApiData *data);

// Add a new Donor
tError api_addPerson(tApiData *data, tCSVEntry entry);

// Add a new donation to the App
tError api_addDonation(tApiData *data, tCSVEntry donation);

// Get NGO data from CSV entry
tError api_getNGO(tApiData data, const char *ngoCode, tCSVEntry *entry);

// Get project data from CSV entry
tError api_getProject(tApiData data, const char *ngoCode, const char *projectCode, tCSVEntry *entry);

// Get registered NGOs from the app
tError api_getNGOs(tApiData data, tCSVData *ngos);

// Get registered projects from the app
tError api_getProjects(tApiData data, tCSVData *projects);

// Get the number of people registered on the app
int api_peopleCount(tApiData data);

// Get the number of NGOs registered on the app
int api_ngoCount(tApiData data);

// Get the number of projects registered on the app
int api_projectCount(tApiData data);

// Get the budget registered on a the app
float api_ngoProjectBudget(tApiData data, const char *ngoCode, const char *projectCode);

//Adds a call based on user identification document
tError api_ngoAddCall(char *document, tNGO *ngo);

//Returns the first benefactor and deletes it from the call list
char* api_ngoMakeCall(tNGO *ngo);

//returns total amount of donations to the NGO
float api_ngoIncome(tApiData data, char *ngoCode);

//returns the number of projects contained in the structure
int api_ngoProjectCount(tApiData data, char *ngoCode);

//[[AUX]] Get Person from Person's list
tPerson* api_getPerson(char *document, tApiData *data);

// Add calls to donators to the queue, starting with donators with bigger amount of money
tError api_FillCallQueue(tApiData *data, const char *ngoCode);

// Get the project with the biggest budget from all NGOs
tProject* api_MostValuableProject(tApiData data);

#endif	// __UOCNGO_API__H