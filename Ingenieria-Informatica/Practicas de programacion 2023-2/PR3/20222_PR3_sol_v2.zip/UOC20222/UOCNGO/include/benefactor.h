#ifndef __BENEFACTOR_H__
#define __BENEFACTOR_H__

#include <stdbool.h>
#include "error.h"
#include "csv.h"
#include "project.h"
#include "person.h"



typedef struct _tBenefactor
{		
	tPerson *person;
	float totalAmount;
	
}tBenefactor;

typedef struct _tBenefactorData{		
	tBenefactor *elems;
	int count;
}tBenefactorData;


void benefactor_init(tPerson *person, tBenefactor *benefactor);
void benefactor_free(tBenefactor *benefactor);
void benefactor_parse(tBenefactor *benefactor, tCSVEntry donor); 
 
tError benefactorData_init(tBenefactorData* data);

void benefactorData_free(tBenefactorData* data);

int benefactorData_len(tBenefactorData data);

tError benefactorData_add (tBenefactor* benefactor, tBenefactorData *data);
tBenefactor* benefactorData_get (int position, tBenefactorData data);
tError benefactorData_del(char *document, tBenefactorData *data);
tBenefactor *benefactorData_find (char *code, tBenefactorData data);
float benefactorData_TotalAmount (tBenefactorData data);


//[AUX] Find Benefactor array position
int findBenefactorPosInList(char *document, tBenefactorData benefactorData);

//[AUX] Find Person in Benefactors
tError findBenefactorInList(tBenefactor benefactor, tBenefactorData benefactorData);

// [AUX] Method performing quicksort
void quicksort(tBenefactor* people, int begin, int end);


// Search using binary search a benefactor in the list of benefactors
tBenefactor *benefactorData_findBS(char *code, tBenefactorData data);

// Sort list of benefactors by total money amount
tError benefactorData_SortByAmount(tBenefactorData src, tBenefactorData *dst);


// [AUX] copy input list
void benefactorData_clone(tBenefactorData src, tBenefactorData *dst);

// [AUX] quicksort using amount
void benefactorData_quicksort(tBenefactorData* benefactors, int begin, int end);

// [AUX] binary search by document
int benefactorData_binarySearch(tBenefactorData benefactors, int first, int last, const char *value);

#endif //__BENEFACTOR_H__