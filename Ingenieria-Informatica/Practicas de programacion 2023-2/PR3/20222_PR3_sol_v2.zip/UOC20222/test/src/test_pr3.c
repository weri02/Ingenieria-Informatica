#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "test_pr3.h"
#include "benefactor.h"
#include "ngo.h"
#include "callQueue.h"
#include "api.h"
#include "csv.h"
#include "error.h"


// Run all tests for PR3
bool run_pr3(tTestSuite* test_suite, const char* input)
{
	bool ok = true;
	tTestSection* section = NULL;

	assert(test_suite != NULL);

	testSuite_addSection(test_suite, "PR3", "Tests for PR3 exercises");

	section = testSuite_getSection(test_suite, "PR3");
	assert(section != NULL);

	ok = run_pr3_ex1(section, input);
	ok = run_pr3_ex2(section, input) && ok;
	ok = run_pr3_ex3(section, input) && ok;

	return ok;
}

// Run all tests for Exercice 1 of PR3
bool run_pr3_ex1(tTestSection* test_section, const char* input)
{
	tBenefactorData *benefactorData = NULL;
    tProjectList *projects = NULL;
    tBenefactorData emptyBenefactors;
    tProjectList emptyProjects;
	tBenefactor *test1, *test2, *test3; // helpers for comparisons
    tProject *mvp = NULL;
	bool exercisePassed = true;
	bool testPassed = true; // determines if test is passed or not
	bool t1=false, t2=false; // helpers for comparison
	bool fail_all = false;
    tApiData data;
    
	// Initialize the data    
    if (api_initData(&data) != E_SUCCESS) {
        fail_all = true;
    }    
    if (!fail_all && api_loadData(&data, input, true) != E_SUCCESS) {
        fail_all = true;
    }

	/////////////////////////////
	/////  PR3 EX1 TEST 1  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX1_1", "Find Benefactor using Binary Search");
    
    if (!fail_all && data.NGOs.count > 0 && data.NGOs.first != NULL) {
        
        benefactorData_init(&emptyBenefactors);
                
        test1 = benefactorData_findBS("B7843746J", emptyBenefactors); 
        test2 = benefactorData_findBS("C8982734F", emptyBenefactors);
        test3 = benefactorData_findBS("F9632587L", emptyBenefactors);

        if (test1 == NULL && test2 == NULL && test3 == NULL) {
            // As NGOs are sorted by code, we take the benefactors from "Against Malaria Foundation" (AMF)
            benefactorData = &(data.NGOs.first->elem.benefactors);
            
            test1 = benefactorData_findBS("B7843746J", *benefactorData); // Is not an AMF donator
            test2 = benefactorData_findBS("C8982734F", *benefactorData);
            test3 = benefactorData_findBS("F9632587L", *benefactorData);           

            if (test1 == NULL && test2 != NULL && test3 != NULL) {
            
                t1 = strcmp(test2->person->document, "C8982734F");
                t2 = strcmp(test3->person->document, "F9632587L");
            
                if (!t1 && !t2) {
                    testPassed= true;
                }
            }
        }

        test1 = NULL;
        test2 = NULL;
        test3 = NULL;

        t1 = false;
        t2 = false;

        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
        
        benefactorData_free(&emptyBenefactors);
    }
	end_test(test_section, "PR3_EX1_1", testPassed);    
    
    
    /////////////////////////////
	/////  PR3 EX1 TEST 2  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX1_2", "Find Most Valuable Project");
    
    if (!fail_all) {
        projectList_init(&emptyProjects);
        
        mvp = projectList_findMostValuable(&emptyProjects);
        
        if (mvp == NULL) {
            // As NGOs are sorted by code, we take the projects from "Against Malaria Foundation" (AMF)
            projects = &(data.NGOs.first->elem.projects);
            
            mvp = projectList_findMostValuable(projects);
            
            if (mvp != NULL && !strcmp(mvp->code, "KENYA")) {
                testPassed = true;
            }
        }
        
        projectList_free(&emptyProjects);        
    }
    
    end_test(test_section, "PR3_EX1_2", testPassed);

    api_freeData(&data);

	return exercisePassed;
}

//Run all tests for Exercice 2 of PR3
bool run_pr3_ex2(tTestSection* test_section, const char* input)
{	
    tBenefactorData *benefactorData = NULL;    
    tBenefactorData emptyBenefactors;    
    tBenefactorData outputBenefactors;  
    tApiData data;
    bool exercisePassed = true;
	bool testPassed = true; 	
	bool fail_all = false;
    int i;
    
	// Initialize the data    
    if (api_initData(&data) != E_SUCCESS) {
        fail_all = true;
    }    
    if (!fail_all && api_loadData(&data, input, true) != E_SUCCESS) {
        fail_all = true;
    }

	/////////////////////////////
	/////  PR3 EX2 TEST 1  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX2_1", "Sort an empty list");
    
    if (!fail_all && data.NGOs.count > 0 && data.NGOs.first != NULL) {
        
        benefactorData_init(&emptyBenefactors);
        benefactorData_init(&outputBenefactors);
        
        if (benefactorData_SortByAmount(emptyBenefactors, &outputBenefactors) == E_SUCCESS && outputBenefactors.count == 0 && outputBenefactors.elems == NULL) {
            testPassed = true;
        }

        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
        
        benefactorData_free(&emptyBenefactors);
        benefactorData_free(&outputBenefactors);
    }
	end_test(test_section, "PR3_EX2_1", testPassed);    
    
    /////////////////////////////
	/////  PR3 EX2 TEST 2  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX2_2", "Sort a list of benefactors");
    
    if (!fail_all && data.NGOs.count > 0 && data.NGOs.first != NULL) {
        
        // As NGOs are sorted by code, we take the benefactors from "Against Malaria Foundation" (AMF)
        benefactorData = &(data.NGOs.first->elem.benefactors);
        
        benefactorData_init(&outputBenefactors);
        
        if (benefactorData_SortByAmount(*benefactorData, &outputBenefactors) == E_SUCCESS && outputBenefactors.count == benefactorData->count) {
            testPassed = true;            
            for(i = 1; i < outputBenefactors.count; i++) {
                if (outputBenefactors.elems[i-1].totalAmount < outputBenefactors.elems[i].totalAmount + 0.00000001f) {
                    testPassed = false;
                }
            }            
        }

        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
        
        benefactorData_free(&outputBenefactors);
    }
	end_test(test_section, "PR3_EX2_2", testPassed);    
    
    api_freeData(&data);

	return exercisePassed;
}

//Run all tests for Exercice 3 of PR2
bool run_pr3_ex3(tTestSection* test_section, const char* input)
{
    tApiData data;
    bool exercisePassed = true;
	bool testPassed = true; 	
	bool fail_all = false;
    tError error;
    tNGO* ngo = NULL;    
    tBenefactor *pBenefactor1, *pBenefactor2;
    tProject *pProject;
    
	// Initialize the data    
    if (api_initData(&data) != E_SUCCESS) {
        fail_all = true;
    }    
    if (!fail_all && api_loadData(&data, input, true) != E_SUCCESS) {
        fail_all = true;
    }

	/////////////////////////////
	/////  PR3 EX3 TEST 1  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX3_1", "Call to donators of a non existing NGO");
    
    if (!fail_all) {
        
        error = api_FillCallQueue(&data, "NOT_EXISTING_NGO");
        
        if (error != E_NOT_IMPLEMENTED && error != E_SUCCESS) {
            testPassed = true;
        }

        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;        
    }
	end_test(test_section, "PR3_EX3_1", testPassed);    
    
    /////////////////////////////
	/////  PR3 EX3 TEST 2  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX3_2", "Call donators from an existing NGO");
    
    if (!fail_all && data.NGOs.count > 0 && data.NGOs.first != NULL) {
        
        ngo = ngoList_find(&(data.NGOs), "WFP");        
        
        if (callQueue_empty(&(ngo->calls))) {
        
            error = api_FillCallQueue(&data, "WFP");
            
            if (error == E_SUCCESS && !callQueue_empty(&(ngo->calls))) {                
                testPassed = true;
                pBenefactor1 = callQueue_head(&(ngo->calls));
                while(!callQueue_empty(&(ngo->calls))) {
                    pBenefactor2 = callQueue_dequeue(&(ngo->calls));
                    if (pBenefactor1->totalAmount < pBenefactor2->totalAmount + 0.0000001f) {
                        testPassed = false;
                    }
                    pBenefactor1 = pBenefactor2;
                }                
            }       
        }        

        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR3_EX3_2", testPassed);    
    
    /////////////////////////////
	/////  PR3 EX3 TEST 3  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX3_3", "Get most valuable project");
    
    if (!fail_all) {
        
        pProject = api_MostValuableProject(data);
        
        if (pProject != NULL && fabs(pProject->budget - 1000000) < 0.00001f  && !strcmp(pProject->ngoCode, "WCK") ) {
            testPassed = true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR3_EX3_3", testPassed);    
    
    api_freeData(&data);
    
    /////////////////////////////
	/////  PR3 EX3 TEST 4  //////
	/////////////////////////////    
    testPassed = false;
	start_test(test_section, "PR3_EX3_4", "Get most valuable project from empty data");
    
    if (!fail_all) {
        
        pProject = api_MostValuableProject(data);
        
        if (pProject == NULL) {
            testPassed = true;
        }
        
        // Fail other tests if this fails to avoid memory leaks
        fail_all = !testPassed;
    }
	end_test(test_section, "PR3_EX3_4", testPassed);    

	return exercisePassed;
}
