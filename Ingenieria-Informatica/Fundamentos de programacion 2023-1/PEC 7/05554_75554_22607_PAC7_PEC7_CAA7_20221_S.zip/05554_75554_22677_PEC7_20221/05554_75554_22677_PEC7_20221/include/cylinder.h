/*
* File: ciylinder.h
* Author: UOC
* Course: 20221
* Description: PAC7-PEC7-CAA7
*/

#include <stdio.h>

#define MAX_NAME 15+1
#define BREATH_VOLUME_MINUTE 40.0

typedef struct {
    char brandName[MAX_NAME];
    float weight;
    float volume;
    float pressure;
} tCylinder;

/* Predeclaracions */
void readCylinder(tCylinder *cylinder);
void writeCylinder(tCylinder cylinder);
void copyCylinder(tCylinder *dstCyl, tCylinder srcCyl);
void selectCylinder(tCylinder cyl1, tCylinder cyl2, tCylinder *selCyl);