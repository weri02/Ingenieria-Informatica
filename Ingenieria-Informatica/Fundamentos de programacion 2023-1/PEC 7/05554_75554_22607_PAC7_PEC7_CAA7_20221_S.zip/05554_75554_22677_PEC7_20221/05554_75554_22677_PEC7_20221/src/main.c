/*
* File: main.h
* Author: UOC
* Course: 20221
* Description: PAC7-PEC7-CAA7
*/
#include <stdio.h>
#include <string.h>
#include "cylinder.h"

int main(int argc, char **argv) {
	
	tCylinder cyl1; 
	tCylinder cyl2; 
	tCylinder selCyl;
	
	 /* Input data */
    printf("INPUT\n");
    printf("CYLINDER 1\n");
    readCylinder(&cyl1);
    printf("CYLINDER 2\n");
    readCylinder(&cyl2);

    /* Calculations */
    selectCylinder(cyl1, cyl2, &selCyl);

    /* Output data */
    printf("OUTPUT\n");
    printf("SELECTED CYLINDER IS:\n");
    writeCylinder(selCyl);	
		
	return 0;
}