/*
* File: ciylinder.c
* Author: UOC
* Course: 20221
* Description: PAC7-PEC7-CAA7
*/

#include <stdio.h>
#include <string.h>
#include "cylinder.h"

void readCylinder(tCylinder *cylinder) {
	printf("BRAND NAME?\n");
    scanf("%s", cylinder->brandName);
    printf("WEIGHT (4.5-6.5 KG)?\n");
    scanf("%f", &cylinder->weight);
	printf("VOLUME (6.5-8.5 KG)?\n");
    scanf("%f", &cylinder->volume);
	printf("PRESSURE (250-300 ATM)?\n");
    scanf("%f", &cylinder->pressure);
}

void writeCylinder(tCylinder cylinder) {
	printf("BRAND NAME: %s\n", cylinder.brandName);
	printf("WEIGHT: %.2f\n", cylinder.weight);
	printf("VOLUME: %.2f\n", cylinder.volume);
	printf("PRESSURE: %.2f\n", cylinder.pressure);
	printf("WORKING TIME [MINS]: %.2f\n", (cylinder.volume * cylinder.pressure) / BREATH_VOLUME_MINUTE);
}

void copyCylinder(tCylinder *dstCyl, tCylinder srcCyl){
	strcpy(dstCyl->brandName, srcCyl.brandName);
	dstCyl->weight = srcCyl.weight;
	dstCyl->volume = srcCyl.volume;
	dstCyl->pressure = srcCyl.pressure;
}

void selectCylinder(tCylinder cyl1, tCylinder cyl2, tCylinder *selCyl) {
	
	float workingTimeCyl1;
	float workingTimeCyl2;
	
	workingTimeCyl1 = (cyl1.volume * cyl1.pressure) / BREATH_VOLUME_MINUTE;
	workingTimeCyl2 = (cyl2.volume * cyl2.pressure) / BREATH_VOLUME_MINUTE;
		
	if (workingTimeCyl1 > workingTimeCyl2) {
		copyCylinder(selCyl, cyl1);
	} else {
		if (workingTimeCyl1 < workingTimeCyl2) {
			copyCylinder(selCyl, cyl2);
		} else {
			if (cyl1.weight <= cyl2.weight) {
				copyCylinder(selCyl, cyl1);
			}
			else{
				copyCylinder(selCyl, cyl2);
			}
		}
	}
}